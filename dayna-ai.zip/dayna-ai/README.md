# Dayna AI — voice-powered smart billing

Voice billing, UPI payments (GPay / PhonePe / Paytm / BHIM) with QR + scanner, payment history, reports and PDF invoices for small Indian shops.

## Run
```bash
npm install
npm start            # http://localhost:3000
npm test             # 23 API checks (voice parsing, billing math, stock, payments, PDF, reports)
```
Needs Node 18+. Use **Chrome or Edge** for the microphone. Camera (QR scanner) and mic need `localhost` or HTTPS.

## MongoDB
```bash
export MONGODB_URI='mongodb+srv://user:pass@cluster.mongodb.net/'   # or mongodb://localhost:27017
export MONGODB_DB=dayna_ai                                           # optional
npm start
```
On first start with an empty database it seeds the demo catalogue (or migrates an existing `data/db.json`). The server refuses to start if MongoDB is unreachable.

## First 2 minutes
1. **Settings** → shop name, address, **your UPI ID** (enables QR + GPay/PhonePe/Paytm links), tax rules (GST is OFF until you enable it).
2. **Products** → the demo catalogue is *sample data* — edit prices/stock to your own, add spoken aliases (coke, कोक…), or import a CSV (`name,brand,sku,size,unit,price,cost,stock,lowStock,taxRate,aliases`).
3. **Billing** → tap the mic: *"Bhai, do Thums Up 750 ml, teen Bisleri ki bottle aur ek Sprite de do"*. Ambiguous items (two Bisleri sizes) show choice chips instead of being guessed.
4. **Confirm & finalize** → stock updates once → **Collect payment** → cash / UPI app QR / card → **Payments** shows history.

## Architecture
| Part | How |
|---|---|
| Backend | `server.js` (Express). **MongoDB** when `MONGODB_URI` is set (collections: settings, meta, products, invoices, payments, movements, audit; only changed documents are written). Falls back to `data/db.json` when unset. |
| Money | Integer paise everywhere, quantities in thousandths. No floats in totals. Server recomputes every total. |
| Voice | Browser Web Speech API → `/api/voice/parse` → structured actions (`ADD_ITEM, REMOVE_ITEM, UPDATE_QUANTITY, QUERY_SALES, CHECK_STOCK, CREATE_INVOICE, SHARE_INVOICE, GENERATE_REPORT`) → **schema validator** → only then applied to the cart. The parser never touches the database. |
| AI provider | Built-in multilingual rules parser (Hindi / English / Hinglish / Odia numbers & keywords). Set `ANTHROPIC_API_KEY` to use Claude for deeper understanding — its output goes through the same validator, with rules as fallback. |
| Safety | No guessing: missing quantity or multiple variants → clarification. Duplicate-submit protection (idempotency key), overstock needs explicit authorization, cancellations need a reason, everything audit-logged (`/api/audit`). |
| Payments | UPI QR + `upi://`, `tez://`, `phonepe://`, `paytmmp://` deep links; cash/card recording; partial payments; duplicate UTR blocked; history with filters + CSV export. |
| Scanner | Camera QR/barcode scanner (native `BarcodeDetector`, bundled jsQR fallback). Payments: reads a customer's UPI QR → fills their UPI ID. Billing: scans product SKU/barcode → adds item. |
| PDF | PDFKit invoice with logo, GSTIN, tax lines, payment status, UPI QR for balance due. |

## Honest limits (read before going live)
- **UPI payments are confirmed manually.** Plain UPI QR/deep links move money straight to your bank, but no app tells Dayna it succeeded. The shopkeeper confirms after seeing the credit, and enters the UTR. For automatic confirmation you need a payment gateway merchant account (Razorpay, PhonePe PG, Cashfree…) and a webhook — not included.
- **Speech recognition** uses the browser engine. Hindi/English work well in Chrome; **Odia speech-to-text is not supported by most browsers** — Odia *typed* commands and Odia replies work, and `server.js` is the place to plug in a server-side STT provider (Google/Azure/Bhashini) for Odia voice.
- **Email** needs `SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM` env vars; otherwise the app opens your mail app instead.
- **WhatsApp** uses click-to-chat (`wa.me`) with a prefilled message. The invoice *link* only works for customers once the app is hosted online; “Share PDF…” attaches the actual file on phones. Official WhatsApp Business API is not included.
- Add login/roles, HTTPS and a real database before multi-user or public hosting.
