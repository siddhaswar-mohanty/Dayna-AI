'use strict';
/**
 * Dayna AI - backend
 * - Persistence: MongoDB (set MONGODB_URI) or JSON-file fallback with atomic writes.
 * - All money is stored as integer paise. Quantities are handled in thousandths. No floats in totals.
 * - Voice text -> structured actions -> schema validation -> only then applied to the cart.
 *   The AI/parser never writes to the database; only validated REST endpoints do.
 */
const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PDFDocument = require('pdfkit');
const QRCode = require('qrcode');
let nodemailer = null;
try { nodemailer = require('nodemailer'); } catch (e) { /* optional */ }

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

/* ------------------------------------------------------------------ utils */
const uid = (p) => p + '_' + crypto.randomBytes(5).toString('hex');
class HttpError extends Error { constructor(status, message, extra) { super(message); this.status = status; this.extra = extra || {}; } }
const bad = (status, msg, extra) => { throw new HttpError(status, msg, extra); };

/** Parse "12", "12.5", "12.50" into integer paise without floats. */
function paise(v) {
  const s = String(v == null ? '' : v).trim();
  if (!/^\d+(\.\d{1,2})?$/.test(s)) bad(400, 'Invalid amount: ' + s);
  const [a, b = ''] = s.split('.');
  return parseInt(a, 10) * 100 + parseInt((b + '00').slice(0, 2), 10);
}
const fmtP = (p) => Math.floor(p / 100).toLocaleString('en-IN') + '.' + String(p % 100).padStart(2, '0');
const qtyMilli = (q) => Math.round(Number(q) * 1000);

/* ------------------------------------------------------------------ store */
function defaultDb() {
  const P = (name, brand, sizeVal, sizeUnit, unit, price, cost, stock, aliases, sku) => ({
    id: uid('p'), sku, name, brand, variant: sizeVal ? sizeVal + ' ' + sizeUnit : '', sizeVal, sizeUnit, unit,
    pricePaise: price * 100, costPaise: cost * 100, stock, lowStock: 6, trackStock: true, taxRate: null,
    aliases, archived: false, sample: true, createdAt: Date.now()
  });
  const products = [
    P('Thums Up', '', 750, 'ml', 'bottle', 40, 32, 48, ['thumbs up', 'thums up', 'थम्स अप', 'ଥମ୍ସ ଅପ'], 'TU750'),
    P('Thums Up', '', 250, 'ml', 'bottle', 20, 16, 60, ['thumbs up', 'thums up', 'थम्स अप'], 'TU250'),
    P('Coca-Cola', '', 750, 'ml', 'bottle', 40, 32, 36, ['coke', 'coca cola', 'cocacola', 'कोक', 'कोका कोला'], 'CC750'),
    P('Sprite', '', 250, 'ml', 'bottle', 20, 16, 60, ['sprite', 'स्प्राइट'], 'SP250'),
    P('Sprite', '', 750, 'ml', 'bottle', 40, 32, 30, ['sprite', 'स्प्राइट'], 'SP750'),
    P('Bisleri Water', 'Bisleri', 1, 'l', 'bottle', 20, 14, 80, ['bisleri', 'water', 'paani', 'pani', 'packaged water', 'बिसलेरी', 'ବିସଲେରୀ'], 'BIS1L'),
    P('Bisleri Water', 'Bisleri', 500, 'ml', 'bottle', 10, 7, 90, ['bisleri', 'water', 'paani', 'pani', 'बिसलेरी'], 'BIS500'),
    P('Maaza', '', 250, 'ml', 'bottle', 20, 16, 40, ['maaza', 'maza', 'mango drink', 'माज़ा'], 'MZ250'),
    P('Tea', '', null, null, 'cup', 10, 4, 0, ['chai', 'tea', 'चाय'], 'TEA')
  ];
  products[8].trackStock = false;
  return {
    settings: {
      shopName: 'My Shop', address: '', phone: '', email: '', gstin: '', upiId: '', upiName: '', logo: '',
      taxEnabled: false, taxMode: 'exclusive', defaultTaxRate: 0, trackStock: true,
      invoicePrefix: 'INV', invoiceSeq: 0, timezone: 'Asia/Kolkata'
    },
    products, invoices: [], payments: [], movements: [], audit: [], idem: {}
  };
}
let db;
/* Persistence: MongoDB when MONGODB_URI is set, otherwise the JSON file (atomic writes). */
const MONGO_URI = process.env.MONGODB_URI || process.env.MONGO_URI || '';
const MONGO_DB = process.env.MONGODB_DB || 'dayna_ai';
const MONGO_COLLS = ['products', 'invoices', 'payments', 'movements', 'audit'];
let mongo = null, mongoSnap = {}, mongoQueue = Promise.resolve();

function load() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (fs.existsSync(DB_FILE)) { try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch (e) { db = defaultDb(); } }
  else { db = defaultDb(); if (!MONGO_URI) save(); }
}
function save() {
  if (MONGO_URI) { if (mongo) mongoQueue = mongoQueue.then(mongoSync).catch((e) => console.error('MongoDB write failed:', e.message)); return; }
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DB_FILE);
}
const stripId = (d) => { const { _id, ...rest } = d; return rest; };
function mongoDocs() {
  const e = { settings: [{ id: 'main', ...db.settings }], meta: [{ id: 'idem', map: db.idem }] };
  for (const c of MONGO_COLLS) e[c] = db[c];
  return e;
}
/** Writes only documents that changed since the last sync (per-document upsert/delete). */
async function mongoSync() {
  const snap = {}, ops = {}, docs = mongoDocs();
  for (const name of Object.keys(docs)) {
    snap[name] = new Map(); const prev = mongoSnap[name] || new Map(); const o = [];
    for (const d of docs[name]) {
      const json = JSON.stringify(d); snap[name].set(d.id, json);
      if (prev.get(d.id) !== json) o.push({ replaceOne: { filter: { _id: d.id }, replacement: { ...d, _id: d.id }, upsert: true } });
    }
    const gone = [...prev.keys()].filter((k) => !snap[name].has(k));
    if (gone.length) o.push({ deleteMany: { filter: { _id: { $in: gone } } } });
    if (o.length) ops[name] = o;
  }
  for (const name of Object.keys(ops)) await mongo.collection(name).bulkWrite(ops[name], { ordered: false });
  mongoSnap = snap;
}
async function initMongo() {
  const { MongoClient } = require('mongodb');
  const client = new MongoClient(MONGO_URI, { serverSelectionTimeoutMS: 8000 });
  await client.connect();
  const m = client.db(MONGO_DB);
  const settings = await m.collection('settings').findOne({ _id: 'main' });
  if (settings) {
    const meta = await m.collection('meta').findOne({ _id: 'idem' });
    const s = stripId(settings); delete s.id;
    const loaded = { settings: s, idem: meta ? meta.map : {} };
    for (const c of MONGO_COLLS) loaded[c] = (await m.collection(c).find({}).toArray()).map(stripId).sort((a, b) => (a.createdAt || a.at || 0) - (b.createdAt || b.at || 0));
    db = loaded; mongo = m; mongoSnap = {};
    const docs = mongoDocs();
    for (const n of Object.keys(docs)) mongoSnap[n] = new Map(docs[n].map((d) => [d.id, JSON.stringify(d)]));
    console.log(`MongoDB connected (${MONGO_DB}): ${db.products.length} products, ${db.invoices.length} invoices loaded`);
  } else {
    // first run: db already holds data/db.json (migration) or the demo defaults
    mongo = m; mongoSnap = {};
    await mongoSync();
    console.log(`MongoDB connected (${MONGO_DB}): empty database, seeded ${fs.existsSync(DB_FILE) ? 'from data/db.json' : 'with default data'}`);
  }
  await m.collection('invoices').createIndex({ status: 1 }).catch(() => {});
  await m.collection('payments').createIndex({ at: -1 }).catch(() => {});
}
const audit = (action, ref, detail) => db.audit.push({ id: uid('a'), at: Date.now(), action, ref, detail: detail || null });
const findProduct = (id) => db.products.find((p) => p.id === id);

/* ---------------------------------------------------------- billing engine */
function priceCart(cart, invDiscountPaise) {
  const S = db.settings;
  const lines = [];
  let gross = 0, discount = 0, tax = 0, total = 0;
  for (const c of cart || []) {
    const p = findProduct(c.productId);
    if (!p || p.archived) bad(400, 'Unknown or archived product: ' + c.productId);
    const qm = qtyMilli(c.qty);
    if (!(qm > 0) || qm > 1e7) bad(400, 'Invalid quantity for ' + p.name);
    const g = Math.round((qm * p.pricePaise) / 1000);
    const d = Math.min(Math.max(parseInt(c.discountPaise || 0, 10) || 0, 0), g);
    const net = g - d;
    const rate = S.taxEnabled ? (p.taxRate == null ? Number(S.defaultTaxRate) || 0 : Number(p.taxRate)) : 0;
    let t = 0, lt = net;
    if (rate > 0) {
      if (S.taxMode === 'inclusive') t = net - Math.round((net * 100) / (100 + rate));
      else { t = Math.round((net * rate) / 100); lt = net + t; }
    }
    lines.push({
      productId: p.id, sku: p.sku, name: p.name, brand: p.brand, variant: p.variant, unit: p.unit, qty: qm / 1000,
      unitPaise: p.pricePaise, grossPaise: g, discountPaise: d, taxRate: rate, taxPaise: t, totalPaise: lt, trackStock: p.trackStock
    });
    gross += g; discount += d; tax += t; total += lt;
  }
  const invD = Math.min(Math.max(parseInt(invDiscountPaise || 0, 10) || 0, 0), total);
  return { lines, grossPaise: gross, lineDiscountPaise: discount, invoiceDiscountPaise: invD, taxPaise: tax, grandPaise: total - invD, taxMode: S.taxMode, taxEnabled: S.taxEnabled };
}

function stockShortages(lines) {
  if (!db.settings.trackStock) return [];
  const need = {};
  for (const l of lines) if (l.trackStock) need[l.productId] = (need[l.productId] || 0) + l.qty;
  return Object.entries(need).filter(([id, q]) => findProduct(id).stock < q - 1e-9)
    .map(([id, q]) => ({ productId: id, name: findProduct(id).name, variant: findProduct(id).variant, requested: q, available: findProduct(id).stock }));
}
function moveStock(productId, delta, reason, ref) {
  const p = findProduct(productId);
  if (!p || !p.trackStock || !db.settings.trackStock) return;
  p.stock = Math.round((p.stock + delta) * 1000) / 1000;
  db.movements.push({ id: uid('m'), at: Date.now(), productId, delta, balance: p.stock, reason, ref });
}
function paymentStatus(inv) {
  const due = inv.totals.grandPaise - inv.paidPaise;
  if (inv.totals.grandPaise === 0 || due <= 0) return 'paid';
  return inv.paidPaise > 0 ? 'partial' : 'unpaid';
}
function dayKey(ts) { return new Date(ts).toLocaleDateString('en-CA', { timeZone: db.settings.timezone || 'Asia/Kolkata' }); }

function finalizeInvoice(body, existing) {
  const cart = body.cart;
  if (!Array.isArray(cart) || !cart.length) bad(400, 'Bill is empty');
  if (body.idempotencyKey && db.idem[body.idempotencyKey]) {
    const prev = db.invoices.find((i) => i.id === db.idem[body.idempotencyKey]);
    if (prev) return { invoice: prev, duplicate: true };
  }
  const totals = priceCart(cart, body.discountPaise);
  const short = stockShortages(totals.lines);
  if (short.length && !body.authorizeOverstock) bad(409, 'Not enough stock for some items', { code: 'INSUFFICIENT_STOCK', shortages: short });
  const S = db.settings;
  S.invoiceSeq += 1;
  const d = dayKey(Date.now()).replace(/-/g, '');
  const number = `${S.invoicePrefix || 'INV'}-${d}-${String(S.invoiceSeq).padStart(4, '0')}`;
  const customer = {
    name: String((body.customer && body.customer.name) || '').slice(0, 80),
    phone: String((body.customer && body.customer.phone) || '').replace(/[^\d+]/g, '').slice(0, 15),
    email: String((body.customer && body.customer.email) || '').slice(0, 100)
  };
  const inv = existing || { id: uid('inv'), createdAt: Date.now(), payments: [], returns: [] };
  Object.assign(inv, { number, status: 'final', finalizedAt: Date.now(), customer, cart, lines: totals.lines, totals, paidPaise: inv.paidPaise || 0, overstockAuthorized: !!(short.length && body.authorizeOverstock) });
  inv.paymentStatus = paymentStatus(inv);
  if (!existing) db.invoices.push(inv);
  for (const l of totals.lines) moveStock(l.productId, -l.qty, 'sale', inv.id);
  if (body.idempotencyKey) db.idem[body.idempotencyKey] = inv.id;
  audit('invoice.finalize', inv.id, { number, grand: totals.grandPaise, overstock: inv.overstockAuthorized });
  save();
  return { invoice: inv, duplicate: false };
}

/* ------------------------------------------------------ voice: schema + NLU */
const ACTIONS = ['ADD_ITEM', 'REMOVE_ITEM', 'UPDATE_QUANTITY', 'QUERY_SALES', 'CHECK_STOCK', 'CREATE_INVOICE', 'SHARE_INVOICE', 'GENERATE_REPORT', 'CLARIFY'];
const RANGES = ['today', 'yesterday', 'week', 'lastweek', 'month'];
/** Strict validator: anything that fails is dropped. Returns a clean action or throws. */
function validateAction(a) {
  if (!a || typeof a !== 'object' || !ACTIONS.includes(a.type)) throw new Error('bad action type');
  const num = (v, lo, hi) => { const n = Number(v); if (!isFinite(n) || n <= lo || n > hi) throw new Error('bad number'); return n; };
  const pid = (v) => { const p = findProduct(v); if (!p || p.archived) throw new Error('unknown product'); return v; };
  switch (a.type) {
    case 'ADD_ITEM': return { type: a.type, productId: pid(a.productId), qty: num(a.qty, 0, 10000) };
    case 'UPDATE_QUANTITY': return { type: a.type, productId: pid(a.productId), qty: num(a.qty, 0, 10000) };
    case 'REMOVE_ITEM': return a.last ? { type: a.type, last: true } : { type: a.type, productId: pid(a.productId) };
    case 'CHECK_STOCK': return { type: a.type, productIds: (Array.isArray(a.productIds) ? a.productIds : [a.productId]).map(pid) };
    case 'QUERY_SALES': case 'GENERATE_REPORT': {
      const range = RANGES.includes(a.range) ? a.range : 'today';
      const method = ['cash', 'upi', 'card'].includes(a.method) ? a.method : null;
      return { type: a.type, range, method };
    }
    case 'SHARE_INVOICE': return { type: a.type, channel: ['whatsapp', 'email', 'native'].includes(a.channel) ? a.channel : 'whatsapp' };
    case 'CLARIFY': return { type: a.type, query: String(a.query || '').slice(0, 60), qty: a.qty == null ? null : num(a.qty, 0, 10000), options: (Array.isArray(a.options) ? a.options : []).map(pid) };
    default: return { type: a.type };
  }
}
function applyActionsToCart(cart, actions) {
  let out = (cart || []).map((c) => ({ ...c }));
  for (const a of actions) {
    if (a.type === 'ADD_ITEM') {
      const l = out.find((c) => c.productId === a.productId);
      if (l) l.qty = Math.round((l.qty + a.qty) * 1000) / 1000; else out.push({ productId: a.productId, qty: a.qty, discountPaise: 0 });
    } else if (a.type === 'UPDATE_QUANTITY') {
      const l = out.find((c) => c.productId === a.productId); if (l) l.qty = a.qty;
    } else if (a.type === 'REMOVE_ITEM') {
      if (a.last) out.pop(); else out = out.filter((c) => c.productId !== a.productId);
    }
  }
  return out;
}

const NUMW = {
  ek: 1, ekta: 1, एक: 1, one: 1, ଏକ: 1, do: 2, दो: 2, two: 2, dui: 2, ଦୁଇ: 2, teen: 3, tin: 3, तीन: 3, three: 3, tini: 3, ତିନି: 3,
  char: 4, chaar: 4, char_: 4, चार: 4, four: 4, chari: 4, ଚାରି: 4, panch: 5, paanch: 5, पांच: 5, पाँच: 5, five: 5, pancha: 5, ପାଞ୍ଚ: 5,
  chhe: 6, che: 6, chhah: 6, छह: 6, six: 6, chha: 6, ଛଅ: 6, saat: 7, सात: 7, seven: 7, sata: 7, ସାତ: 7, aath: 8, आठ: 8, eight: 8, atha: 8, ଆଠ: 8,
  nau: 9, नौ: 9, nine: 9, ନଅ: 9, das: 10, दस: 10, ten: 10, dasa: 10, ଦଶ: 10, aadha: 0.5, adha: 0.5, आधा: 0.5, half: 0.5, dedh: 1.5, डेढ़: 1.5, dhai: 2.5, ढाई: 2.5
};
const FILL = new Set(('bhai bhaiya yaar please plz add karo kar kardo de dena dijiye chahiye chaiye mujhe humko hume ki ka ke ko bottle bottles botal can cans pack packs packet packets carton cartons piece pieces pcs pc cup glass wali wala ye aur and the a of to me mein mai ' +
  'जोड़ो करो भाई की का के को बोतल और ଓ ଆଉ ଦିଅ କର ବୋତଲ').split(' '));
const SIZE_RE = /(\d+(?:\.\d+)?)\s*(ml|millilitre|milliliter|l|ltr|litre|liter|kg|kilo|kilogram|g|gm|gram|grams)\b/i;
function sizeBase(val, unit) {
  const u = String(unit || '').toLowerCase(); const v = Number(val);
  if (['ml', 'millilitre', 'milliliter'].includes(u)) return { kind: 'vol', val: v };
  if (['l', 'ltr', 'litre', 'liter'].includes(u)) return { kind: 'vol', val: v * 1000 };
  if (['g', 'gm', 'gram', 'grams'].includes(u)) return { kind: 'mass', val: v };
  if (['kg', 'kilo', 'kilogram'].includes(u)) return { kind: 'mass', val: v * 1000 };
  return null;
}
const lev = (a, b) => { const m = []; for (let i = 0; i <= a.length; i++) { m[i] = [i]; } for (let j = 1; j <= b.length; j++) m[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) m[i][j] = Math.min(m[i - 1][j] + 1, m[i][j - 1] + 1, m[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return m[a.length][b.length]; };
const tokEq = (a, b) => a === b || (a.length >= 4 && b.length >= 4 && /^[a-z]+$/.test(a) && lev(a, b) <= Math.floor(Math.max(a.length, b.length) / 5));
const tokenize = (s) => (String(s).toLowerCase().normalize('NFC').match(/[\p{L}\p{N}\p{M}]+(?:\.\p{N}+)?/gu) || []);

function detectLang(t) {
  if (/[଀-୿]/.test(t)) return 'or';
  if (/[ऀ-ॿ]/.test(t)) return 'hi';
  if (/\b(bhai|karo|kar|aur|kitna|kitni|hai|hui|de do|batao|dikhao|bacha|ka|ki|ke|pichhle|aaj|do|teen|ek)\b/i.test(t)) return 'hinglish';
  return 'en';
}
const LI = { en: 0, hinglish: 1, hi: 2, or: 3 };
const MSG = {
  added: ['Added {qty} × {name}', '{name} ×{qty} add ho gaya', '{name} ×{qty} जोड़ दिया', '{name} ×{qty} ଯୋଗ କରାଗଲା'],
  which: ['Which {q} do you mean?', '{q} ka kaun sa wala chahiye?', '{q} में से कौन सा चाहिए?', '{q} ମଧ୍ୟରୁ କେଉଁଟି?'],
  howmany: ['How many {name}?', '{name} kitne?', '{name} कितने?', '{name} କେତେ?'],
  notfound: ['I couldn\'t find "{q}" in your catalogue.', '"{q}" catalogue me nahi mila.', '"{q}" कैटलॉग में नहीं मिला।', '"{q}" ମିଳିଲା ନାହିଁ।'],
  removed: ['Removed {name}', '{name} hata diya', '{name} हटा दिया', '{name} ହଟାଗଲା'],
  removedLast: ['Removed the last entry', 'Last entry hata di', 'आख़िरी एंट्री हटा दी', 'ଶେଷ ଏଣ୍ଟ୍ରି ହଟାଗଲା'],
  updated: ['{name} set to {qty}', '{name} ki quantity {qty} kar di', '{name} की मात्रा {qty} कर दी', '{name} ପରିମାଣ {qty}'],
  sales: ['{label}: ₹{amt} from {n} bills', '{label} ki sale ₹{amt} ({n} bills)', '{label} की बिक्री ₹{amt} ({n} बिल)', '{label} ବିକ୍ରି ₹{amt} ({n} ବିଲ୍)'],
  stock: ['{name}: {stock} left', '{name}: {stock} bacha hai', '{name}: {stock} बचा है', '{name}: {stock} ବାକି'],
  report: ['Opening the {label} report', '{label} ka report khol raha hoon', '{label} की रिपोर्ट खोल रहा हूँ', '{label} ରିପୋର୍ଟ ଖୋଲୁଛି'],
  share: ['Choose how to share the bill', 'Bill kaise bhejna hai chuniye', 'बिल कैसे भेजना है चुनें', 'ବିଲ୍ କିପରି ପଠାଇବେ'],
  finalize: ['Review the bill and confirm to finalize', 'Bill dekh kar confirm kijiye', 'बिल देखकर कन्फ़र्म करें', 'ବିଲ୍ ଦେଖି ନିଶ୍ଚିତ କରନ୍ତୁ'],
  empty: ['The bill is empty', 'Bill khali hai', 'बिल खाली है', 'ବିଲ୍ ଖାଲି'],
  unknown: ['Sorry, I didn\'t understand. Try "do Coke 750 ml add karo".', 'Samajh nahi aaya. Aise bolein: "do Coke 750 ml add karo".', 'समझ नहीं आया। ऐसे बोलें: "दो कोक 750 ml जोड़ो".', 'ବୁଝିପାରିଲି ନାହିଁ। ପୁଣି କହନ୍ତୁ।']
};
const RLABEL = { today: ['today', 'Aaj', 'आज', 'ଆଜି'], yesterday: ['yesterday', 'Kal', 'कल', 'ଗତକାଲି'], week: ['last 7 days', 'Is hafte', 'इस हफ्ते', 'ଏହି ସପ୍ତାହ'], lastweek: ['last week', 'Pichhle hafte', 'पिछले हफ्ते', 'ଗତ ସପ୍ତାହ'], month: ['this month', 'Is mahine', 'इस महीने', 'ଏହି ମାସ'] };
function R(lang, key, v) {
  const row = MSG[key]; let s = (row[LI[lang]] || row[0]);
  for (const k in (v || {})) s = s.split('{' + k + '}').join(v[k]);
  return s;
}

function matchProducts(tokens, size) {
  let best = 0, cands = [];
  for (const p of db.products) {
    if (p.archived) continue;
    const names = [p.name, p.brand ? p.brand + ' ' + p.name : '', ...(p.aliases || [])].filter(Boolean);
    let sc = 0;
    for (const n of names) {
      const nt = tokenize(n);
      if (nt.length && nt.every((t) => tokens.some((x) => tokEq(t, x)))) sc = Math.max(sc, nt.length);
    }
    if (sc > best) { best = sc; cands = [p]; } else if (sc === best && sc > 0) cands.push(p);
  }
  return { score: best, cands };
}
const convQty = (size, unit) => { // loose goods: "2 kg chini" -> qty 2 in product unit
  const b = sizeBase(size.val, size.unit); if (!b) return null;
  if (unit === 'kg') return b.kind === 'mass' ? b.val / 1000 : null;
  if (unit === 'g') return b.kind === 'mass' ? b.val : null;
  if (unit === 'l' || unit === 'litre') return b.kind === 'vol' ? b.val / 1000 : null;
  if (unit === 'ml') return b.kind === 'vol' ? b.val : null;
  return null;
};

function detectRange(t) {
  if (/(pichh?le|pichh?la|last|gat|पिछले)\s*(hafte|hafta|week|saptah|हफ्ते)/i.test(t)) return 'lastweek';
  if (/(hafte|hafta|week|saptah|हफ्ते|सप्ताह|ସପ୍ତାହ)/i.test(t)) return 'week';
  if (/(mahine|mahina|month|महीने|ମାସ)/i.test(t)) return 'month';
  if (/(\bkal\b|yesterday|कल|ଗତକାଲି)/i.test(t)) return 'yesterday';
  return 'today';
}

function ruleParse(text, cart) {
  const lang = detectLang(text);
  const raw = text.replace(/(\d)(ml|l|ltr|litre|kg|g|gm)\b/gi, '$1 $2');
  const lower = raw.toLowerCase();
  const has = (re) => re.test(lower);
  const actions = [], pending = [];
  const res = { lang, actions, pending, reply: '', data: null, ui: null };
  const clean = lower.replace(/\b(de|dedo|kar|karo|kardo|dena|add)\s+(do|dijiye)\b/g, ' ');

  // --- intents that don't need product matching
  if (has(/(last|aakhri|akhri|pichh?li|आखिरी|आख़िरी|ଶେଷ).*(cancel|hata|remove|delete|हटा|कैंसल|ହଟା)|(cancel|hata|remove|delete).*(last|aakhri|akhri)/)) {
    actions.push({ type: 'REMOVE_ITEM', last: true }); res.reply = R(lang, 'removedLast'); return res;
  }
  if (has(/(whatsapp|share|bhej|send|email|mail|व्हाट्सऐप|व्हाट्सएप|भेज)/)) {
    const ch = has(/(email|mail)/) ? 'email' : has(/(share)/) && !has(/whatsapp/) ? 'native' : 'whatsapp';
    actions.push({ type: 'SHARE_INVOICE', channel: ch }); res.reply = R(lang, 'share'); res.ui = 'share'; return res;
  }
  const tok0 = tokenize(clean);
  const sizeM = clean.match(SIZE_RE);
  const wantsStock = has(/(stock|bacha|bachi|bacha hai|स्टॉक|बचा|ଷ୍ଟକ)/);
  const wantsReport = has(/(report|रिपोर्ट|ରିପୋର୍ଟ)/);
  const wantsSales = has(/(\bsale\b|sales|bikri|बिक्री|becha|ବିକ୍ରି|total cash|cash sale)/);
  if (!wantsStock && (wantsReport || wantsSales)) {
    const range = detectRange(lower); const method = has(/\bcash\b/) ? 'cash' : has(/\bupi\b/) ? 'upi' : has(/\bcard\b/) ? 'card' : null;
    actions.push({ type: wantsReport ? 'GENERATE_REPORT' : 'QUERY_SALES', range, method });
    res.ui = wantsReport ? 'report' : null; return res; // reply filled by caller with real numbers
  }
  if (!wantsStock && has(/(bill bana|bill banao|invoice|finali[sz]e|confirm|checkout|generate bill|bill kar|बिल बना|बिल बनाओ)/)) {
    actions.push({ type: 'CREATE_INVOICE' }); res.reply = R(lang, cart && cart.length ? 'finalize' : 'empty'); res.ui = cart && cart.length ? 'finalize' : null; return res;
  }

  // --- product-centric: split into segments
  const segs = clean.split(/\s+(?:aur|and|tatha|ebong|plus|और|ଆଉ|ଏବଂ)\s+|[,;।]|\bphir\b/).map((s) => s.trim()).filter(Boolean);
  const removeIntent = has(/(remove|hata|hatao|nikal|cancel|delete|हटा|ହଟା)/);
  const updateIntent = has(/(badal|change|update|quantity|set |मात्रा|बदल)/);
  const replies = [];
  for (const seg of segs) {
    let size = null, s2 = seg;
    const sm = seg.match(SIZE_RE);
    if (sm) { size = { val: Number(sm[1]), unit: sm[2] }; s2 = seg.replace(SIZE_RE, ' '); }
    const toks = tokenize(s2);
    let qty = null; const rest = [];
    for (const t of toks) {
      if (qty == null && /^\d+(\.\d+)?$/.test(t)) qty = Number(t);
      else if (qty == null && NUMW[t] != null && toks.length > 1) qty = NUMW[t];
      else if (!FILL.has(t) && !/^\d+(\.\d+)?$/.test(t)) rest.push(t);
    }
    // a lone number word may be a product alias/noise; keep as qty only if other tokens remain
    if (!rest.length) continue;
    let { score, cands } = matchProducts(rest, size);
    if (!score) { if (rest.length) { pending.push({ notFound: true, query: rest.join(' ') }); replies.push(R(lang, 'notfound', { q: rest.join(' ') })); } continue; }
    if (size) {
      const sb = sizeBase(size.val, size.unit);
      const sized = cands.filter((p) => { const b = sizeBase(p.sizeVal, p.sizeUnit); return b && sb && b.kind === sb.kind && Math.abs(b.val - sb.val) < 1e-6; });
      if (sized.length) cands = sized;
      else if (cands.every((p) => !p.sizeVal)) { const q = convQty(size, cands[0].unit); if (q != null && qty == null) qty = q; }
    }
    const label = cands[0].name;
    if (wantsStock) { actions.push({ type: 'CHECK_STOCK', productIds: cands.map((p) => p.id) }); continue; }
    if (removeIntent) {
      if (cands.length === 1) { actions.push({ type: 'REMOVE_ITEM', productId: cands[0].id }); replies.push(R(lang, 'removed', { name: label + ' ' + cands[0].variant })); }
      else { pending.push({ options: cands.map((p) => p.id), qty: null, mode: 'remove', query: label }); replies.push(R(lang, 'which', { q: label })); }
      continue;
    }
    if (cands.length === 1 && qty != null) {
      const p = cands[0];
      if (updateIntent) { actions.push({ type: 'UPDATE_QUANTITY', productId: p.id, qty }); replies.push(R(lang, 'updated', { name: p.name + ' ' + p.variant, qty })); }
      else { actions.push({ type: 'ADD_ITEM', productId: p.id, qty }); replies.push(R(lang, 'added', { name: (p.name + ' ' + p.variant).trim(), qty })); }
    } else {
      pending.push({ options: cands.map((p) => p.id), qty, query: label });
      replies.push(cands.length > 1 ? R(lang, 'which', { q: label }) : R(lang, 'howmany', { name: (label + ' ' + cands[0].variant).trim() }));
    }
  }
  res.reply = replies.join(' · ') || R(lang, 'unknown');
  return res;
}

/** Optional LLM provider: set ANTHROPIC_API_KEY to enable. Output is still schema-validated. */
async function llmParse(text, cart) {
  const key = process.env.ANTHROPIC_API_KEY; if (!key) return null;
  const catalog = db.products.filter((p) => !p.archived).map((p) => ({ id: p.id, name: p.name, variant: p.variant, unit: p.unit, aliases: p.aliases }));
  const sys = 'You convert a shopkeeper\'s spoken command (Hindi, English, Hinglish, Odia) into JSON actions. Reply with JSON only: {"actions":[...]}. ' +
    'Allowed types: ADD_ITEM{productId,qty}, REMOVE_ITEM{productId|last:true}, UPDATE_QUANTITY{productId,qty}, QUERY_SALES{range,method?}, CHECK_STOCK{productIds}, CREATE_INVOICE, SHARE_INVOICE{channel}, GENERATE_REPORT{range}, CLARIFY{query,qty,options:[productIds]}. ' +
    'range is one of today,yesterday,week,lastweek,month. Use ONLY productIds from the catalogue. If the product is ambiguous (several sizes) or quantity is missing, use CLARIFY (qty null if unknown). Never guess.';
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST', headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: process.env.LLM_MODEL || 'claude-sonnet-5-5', max_tokens: 600, system: sys, messages: [{ role: 'user', content: JSON.stringify({ text, catalog, cart }) }] })
  });
  if (!r.ok) throw new Error('LLM http ' + r.status);
  const j = await r.json(); const out = (j.content || []).map((c) => c.text || '').join('');
  const m = out.match(/\{[\s\S]*\}/); if (!m) throw new Error('no json');
  return JSON.parse(m[0]).actions;
}

/* ---------------------------------------------------------------- reports */
function addDays(key, n) { const d = new Date(key + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); }
function rangeBounds(range) {
  const today = dayKey(Date.now());
  switch (range) {
    case 'yesterday': { const y = addDays(today, -1); return { from: y, to: y }; }
    case 'week': return { from: addDays(today, -6), to: today };
    case 'lastweek': return { from: addDays(today, -13), to: addDays(today, -7) };
    case 'month': return { from: today.slice(0, 8) + '01', to: today };
    default: return { from: today, to: today };
  }
}
function buildReport(range, method) {
  const { from, to } = rangeBounds(range);
  const inR = (ts) => { const k = dayKey(ts); return k >= from && k <= to; };
  const invs = db.invoices.filter((i) => i.status === 'final' && inR(i.finalizedAt));
  const pays = db.payments.filter((p) => p.status === 'received' && inR(p.at));
  const byMethod = { cash: 0, upi: 0, card: 0 };
  pays.forEach((p) => { byMethod[p.method] = (byMethod[p.method] || 0) + p.amountPaise; });
  const seriesMap = {};
  for (let k = from; k <= to && Object.keys(seriesMap).length < 62; k = addDays(k, 1)) seriesMap[k] = { date: k, totalPaise: 0, count: 0 };
  const prod = {};
  let gross = 0, tax = 0, disc = 0, returns = 0;
  for (const i of invs) {
    const ret = (i.returns || []).reduce((s, r) => s + r.refundPaise, 0);
    const net = i.totals.grandPaise - ret;
    gross += i.totals.grandPaise; tax += i.totals.taxPaise; disc += i.totals.lineDiscountPaise + i.totals.invoiceDiscountPaise; returns += ret;
    const sd = seriesMap[dayKey(i.finalizedAt)]; if (sd) { sd.totalPaise += net; sd.count++; }
    for (const l of i.lines) { const k = l.productId; prod[k] = prod[k] || { name: (l.name + ' ' + l.variant).trim(), qty: 0, amountPaise: 0 }; prod[k].qty += l.qty; prod[k].amountPaise += l.totalPaise; }
  }
  const outstanding = db.invoices.filter((i) => i.status === 'final').reduce((s, i) => s + Math.max(0, i.totals.grandPaise - i.paidPaise), 0);
  return {
    range, from, to, invoiceCount: invs.length, grossPaise: gross, returnsPaise: returns, netPaise: gross - returns, taxPaise: tax, discountPaise: disc,
    collectedPaise: byMethod.cash + byMethod.upi + byMethod.card, byMethod, methodTotalPaise: method ? byMethod[method] : null, method,
    series: Object.values(seriesMap), top: Object.values(prod).sort((a, b) => b.amountPaise - a.amountPaise).slice(0, 8), outstandingPaise: outstanding,
    lowStock: db.products.filter((p) => !p.archived && p.trackStock && p.stock <= p.lowStock).map((p) => ({ id: p.id, name: (p.name + ' ' + p.variant).trim(), stock: p.stock, lowStock: p.lowStock }))
  };
}

/* ------------------------------------------------------------- UPI + PDF */
function upiParams(amountPaise, note, ref) {
  const S = db.settings;
  if (!S.upiId) bad(400, 'Set your UPI ID in Settings first');
  const q = new URLSearchParams({ pa: S.upiId, pn: S.upiName || S.shopName, cu: 'INR' });
  if (amountPaise > 0) q.set('am', fmtP(amountPaise).replace(/,/g, ''));
  if (note) q.set('tn', note.slice(0, 40));
  if (ref) q.set('tr', ref.slice(0, 35));
  return q.toString();
}

async function renderPdf(inv) {
  const S = db.settings;
  const doc = new PDFDocument({ size: 'A4', margin: 40 });
  const chunks = []; doc.on('data', (c) => chunks.push(c));
  const done = new Promise((r) => doc.on('end', r));
  const L = 40, W = 515; let y = 40;
  if (S.logo && /^data:image\/(png|jpeg);base64,/.test(S.logo)) {
    try { doc.image(Buffer.from(S.logo.split(',')[1], 'base64'), L, y, { fit: [60, 60] }); } catch (e) { /* ignore bad logo */ }
  }
  const hx = S.logo ? L + 72 : L;
  doc.fillColor('#111').font('Helvetica-Bold').fontSize(18).text(S.shopName, hx, y, { width: 300 });
  doc.font('Helvetica').fontSize(9).fillColor('#444');
  [S.address, S.phone && 'Phone: ' + S.phone, S.email, S.gstin && 'GSTIN: ' + S.gstin].filter(Boolean).forEach((t) => doc.text(t, hx, doc.y, { width: 300 }));
  doc.font('Helvetica-Bold').fontSize(20).fillColor('#5b3df5').text('INVOICE', 380, y, { width: 175, align: 'right' });
  doc.font('Helvetica').fontSize(9).fillColor('#333')
    .text('No: ' + inv.number, 380, y + 26, { width: 175, align: 'right' })
    .text('Date: ' + new Date(inv.finalizedAt).toLocaleString('en-IN', { timeZone: S.timezone }), 380, doc.y, { width: 175, align: 'right' })
    .text('Status: ' + inv.paymentStatus.toUpperCase(), 380, doc.y, { width: 175, align: 'right' });
  y = Math.max(doc.y, 120) + 14;
  doc.moveTo(L, y).lineTo(L + W, y).strokeColor('#ddd').stroke(); y += 10;
  const c = inv.customer || {};
  if (c.name || c.phone || c.email) {
    doc.font('Helvetica-Bold').fontSize(9).fillColor('#888').text('BILL TO', L, y);
    doc.font('Helvetica').fontSize(10).fillColor('#111').text([c.name, c.phone, c.email].filter(Boolean).join('  |  '), L, y + 12); y += 36;
  }
  const cols = [L, L + 22, L + 215, L + 270, L + 330, L + 390, L + 445];
  const head = ['#', 'Item', 'Qty', 'Rate', 'Disc', 'Tax', 'Total'];
  doc.rect(L, y, W, 20).fill('#f1effe'); doc.fillColor('#333').font('Helvetica-Bold').fontSize(9);
  head.forEach((h, i) => doc.text(h, cols[i] + 4, y + 6, { width: (cols[i + 1] || L + W) - cols[i] - 8, align: i >= 2 ? 'right' : 'left' }));
  y += 24; doc.font('Helvetica').fillColor('#111');
  inv.lines.forEach((l, i) => {
    if (y > 740) { doc.addPage(); y = 40; }
    const vals = [String(i + 1), (l.name + (l.variant ? ' (' + l.variant + ')' : '')), l.qty + ' ' + l.unit, fmtP(l.unitPaise), fmtP(l.discountPaise), l.taxRate ? l.taxRate + '%' : '-', fmtP(l.totalPaise)];
    vals.forEach((v, k) => doc.text(v, cols[k] + 4, y, { width: (cols[k + 1] || L + W) - cols[k] - 8, align: k >= 2 ? 'right' : 'left', lineBreak: false }));
    y += 18; doc.moveTo(L, y - 4).lineTo(L + W, y - 4).strokeColor('#eee').stroke();
  });
  y += 6; const T = inv.totals;
  const row = (k, v, bold) => { doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(bold ? 12 : 10).fillColor('#111').text(k, 330, y, { width: 100 }).text('Rs. ' + fmtP(v), 430, y, { width: 125, align: 'right' }); y += bold ? 20 : 15; };
  row('Subtotal', T.grossPaise);
  if (T.lineDiscountPaise + T.invoiceDiscountPaise) row('Discount', T.lineDiscountPaise + T.invoiceDiscountPaise);
  if (T.taxPaise) row(T.taxMode === 'inclusive' ? 'Tax (incl.)' : 'Tax', T.taxPaise);
  row('Grand Total', T.grandPaise, true);
  row('Paid', inv.paidPaise); row('Balance due', Math.max(0, T.grandPaise - inv.paidPaise));
  const methods = [...new Set((inv.payments || []).map((p) => p.method.toUpperCase()))].join(', ');
  doc.font('Helvetica').fontSize(9).fillColor('#555').text('Payment method: ' + (methods || (inv.paymentStatus === 'paid' ? '-' : 'Pending')), L, y - 40);
  const due = T.grandPaise - inv.paidPaise;
  if (due > 0 && S.upiId) {
    try {
      const qr = await QRCode.toBuffer('upi://pay?' + upiParams(due, 'Invoice ' + inv.number, inv.number), { margin: 1, width: 220 });
      if (y > 660) { doc.addPage(); y = 40; }
      doc.image(qr, L, y + 10, { width: 100 }); doc.font('Helvetica-Bold').fontSize(10).fillColor('#111').text('Scan to pay Rs. ' + fmtP(due), L + 110, y + 40);
      doc.font('Helvetica').fontSize(9).fillColor('#555').text('UPI: ' + S.upiId + '  (GPay / PhonePe / Paytm / any UPI app)', L + 110, y + 56);
    } catch (e) { /* no qr */ }
  }
  doc.font('Helvetica').fontSize(8).fillColor('#999').text('Generated by Dayna AI · Thank you for shopping with us!', L, 800, { width: W, align: 'center' });
  doc.end(); await done; return Buffer.concat(chunks);
}

/* -------------------------------------------------------------------- app */
load();
const readyP = MONGO_URI ? initMongo() : Promise.resolve();
const app = express();
app.use((q, r, n) => readyP.then(() => n(), n));
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res)).catch(next);
const api = express.Router();
app.use('/api', api);

// Settings
const publicSettings = () => ({ ...db.settings, llm: !!process.env.ANTHROPIC_API_KEY, smtp: !!process.env.SMTP_HOST });
api.get('/settings', (q, r) => r.json(publicSettings()));
api.put('/settings', (q, r) => {
  const b = q.body || {}, S = db.settings;
  for (const k of ['shopName', 'address', 'phone', 'email', 'gstin', 'upiId', 'upiName', 'invoicePrefix']) if (typeof b[k] === 'string') S[k] = b[k].trim().slice(0, 200);
  if (typeof b.logo === 'string') { if (b.logo.length > 400000) bad(400, 'Logo too large (max ~300KB)'); S.logo = b.logo; }
  if (b.upiId && !/^[\w.\-]{2,}@[\w.\-]{2,}$/.test(S.upiId)) bad(400, 'UPI ID looks invalid (example: shop@okhdfcbank)');
  if (b.taxMode) S.taxMode = b.taxMode === 'inclusive' ? 'inclusive' : 'exclusive';
  if (b.taxEnabled != null) S.taxEnabled = !!b.taxEnabled;
  if (b.trackStock != null) S.trackStock = !!b.trackStock;
  if (b.defaultTaxRate != null) { const n = Number(b.defaultTaxRate); if (!(n >= 0 && n <= 100)) bad(400, 'Tax rate must be 0-100'); S.defaultTaxRate = n; }
  audit('settings.update', null); save(); r.json(publicSettings());
});

// Products
function normProduct(b, ex) {
  const p = ex || { id: uid('p'), createdAt: Date.now(), archived: false, stock: 0, aliases: [] };
  if (b.name != null) { if (!String(b.name).trim()) bad(400, 'Name required'); p.name = String(b.name).trim().slice(0, 80); }
  if (!p.name) bad(400, 'Name required');
  if (b.brand != null) p.brand = String(b.brand).trim().slice(0, 60); else if (p.brand == null) p.brand = '';
  if (b.sku != null) p.sku = String(b.sku).trim().slice(0, 40);
  if (b.unit != null) p.unit = String(b.unit).trim().slice(0, 20) || 'piece'; else if (!p.unit) p.unit = 'piece';
  if (b.price != null) p.pricePaise = paise(b.price); else if (p.pricePaise == null) bad(400, 'Price required');
  if (b.cost != null && b.cost !== '') p.costPaise = paise(b.cost); else if (p.costPaise == null) p.costPaise = 0;
  if ('sizeVal' in b || 'sizeUnit' in b) {
    const v = b.sizeVal === '' || b.sizeVal == null ? null : Number(b.sizeVal);
    p.sizeVal = v; p.sizeUnit = v ? String(b.sizeUnit || '').toLowerCase() : null;
    if (v && !sizeBase(v, p.sizeUnit)) bad(400, 'Size unit must be ml, l, g or kg');
  } else if (p.sizeVal === undefined) { p.sizeVal = null; p.sizeUnit = null; }
  p.variant = p.sizeVal ? p.sizeVal + ' ' + p.sizeUnit : (b.variant || p.variant || '');
  if (b.stock != null && b.stock !== '') { const n = Number(b.stock); if (!isFinite(n) || n < 0) bad(400, 'Invalid stock'); if (ex && n !== p.stock) moveStock(p.id, n - p.stock, 'manual adjust', null); else p.stock = n; }
  if (b.lowStock != null && b.lowStock !== '') p.lowStock = Math.max(0, Number(b.lowStock) || 0); else if (p.lowStock == null) p.lowStock = 5;
  if (b.trackStock != null) p.trackStock = !!b.trackStock; else if (p.trackStock == null) p.trackStock = true;
  if (b.taxRate !== undefined) p.taxRate = b.taxRate === '' || b.taxRate === null ? null : Math.min(100, Math.max(0, Number(b.taxRate) || 0));
  else if (p.taxRate === undefined) p.taxRate = null;
  if (b.aliases != null) p.aliases = (Array.isArray(b.aliases) ? b.aliases : String(b.aliases).split(/[;,]/)).map((s) => String(s).trim()).filter(Boolean).slice(0, 20);
  delete p.sample;
  return p;
}
api.get('/products', (q, r) => {
  const s = String(q.query.q || '').toLowerCase(); const arch = q.query.archived === '1';
  r.json(db.products.filter((p) => p.archived === arch && (!s || (p.name + ' ' + p.brand + ' ' + p.sku + ' ' + p.variant + ' ' + p.aliases.join(' ')).toLowerCase().includes(s))));
});
api.post('/products', (q, r) => { const p = normProduct(q.body || {}); if (p.stock && p.trackStock) db.movements.push({ id: uid('m'), at: Date.now(), productId: p.id, delta: p.stock, balance: p.stock, reason: 'opening stock', ref: null }); db.products.push(p); audit('product.create', p.id); save(); r.status(201).json(p); });
api.put('/products/:id', (q, r) => { const p = findProduct(q.params.id) || bad(404, 'Not found'); normProduct(q.body || {}, p); audit('product.update', p.id); save(); r.json(p); });
api.delete('/products/:id', (q, r) => { const p = findProduct(q.params.id) || bad(404, 'Not found'); p.archived = !p.archived; audit(p.archived ? 'product.archive' : 'product.restore', p.id); save(); r.json(p); });
api.get('/products/:id/movements', (q, r) => r.json(db.movements.filter((m) => m.productId === q.params.id).sort((a, b) => b.at - a.at).slice(0, 200)));
function parseCsv(t) {
  const rows = []; let row = [], cur = '', inq = false;
  for (let i = 0; i < t.length; i++) { const ch = t[i];
    if (inq) { if (ch === '"' && t[i + 1] === '"') { cur += '"'; i++; } else if (ch === '"') inq = false; else cur += ch; }
    else if (ch === '"') inq = true; else if (ch === ',') { row.push(cur); cur = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && t[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.some((x) => x.trim())) rows.push(row); row = []; }
    else cur += ch; }
  row.push(cur); if (row.some((x) => x.trim())) rows.push(row); return rows;
}
api.post('/products/import', (q, r) => {
  const rows = parseCsv(String((q.body || {}).csv || '')); if (rows.length < 2) bad(400, 'CSV needs a header row and at least one product');
  const h = rows[0].map((x) => x.trim().toLowerCase()); const col = (k) => h.indexOf(k);
  if (col('name') < 0 || col('price') < 0) bad(400, 'CSV needs at least the columns: name, price');
  let created = 0, updated = 0; const errors = [];
  rows.slice(1).forEach((rw, idx) => {
    const g = (k) => (col(k) >= 0 ? (rw[col(k)] || '').trim() : '');
    try {
      const sm = g('size').match(/^(\d+(?:\.\d+)?)\s*(ml|l|g|kg)$/i);
      const body = { name: g('name'), brand: g('brand'), sku: g('sku'), unit: g('unit') || 'piece', price: g('price'), cost: g('cost'), stock: g('stock'), lowStock: g('lowstock'), taxRate: g('taxrate'), aliases: g('aliases'), sizeVal: sm ? sm[1] : '', sizeUnit: sm ? sm[2] : '' };
      const ex = body.sku ? db.products.find((p) => p.sku === body.sku && !p.archived) : null;
      if (ex) { normProduct(body, ex); updated++; } else { const p = normProduct(body); db.products.push(p); if (p.stock && p.trackStock) db.movements.push({ id: uid('m'), at: Date.now(), productId: p.id, delta: p.stock, balance: p.stock, reason: 'opening stock (import)', ref: null }); created++; }
    } catch (e) { errors.push({ row: idx + 2, error: e.message }); }
  });
  audit('product.import', null, { created, updated, errors: errors.length }); save(); r.json({ created, updated, errors });
});

// Billing
api.post('/billing/preview', (q, r) => r.json(priceCart((q.body || {}).cart, (q.body || {}).discountPaise)));
api.post('/cart/apply', (q, r) => {
  const acts = [];
  for (const a of (q.body || {}).actions || []) { try { acts.push(validateAction(a)); } catch (e) { bad(400, 'Rejected action: ' + e.message); } }
  r.json({ cart: applyActionsToCart((q.body || {}).cart, acts) });
});
api.get('/products/barcode/:code', (q, r) => { const p = db.products.find((x) => !x.archived && x.sku && x.sku.toLowerCase() === q.params.code.toLowerCase()); p ? r.json(p) : bad(404, 'No product with this barcode/SKU'); });

// Voice
api.post('/voice/parse', wrap(async (q, r) => {
  const text = String((q.body || {}).text || '').trim().slice(0, 500); const cart = (q.body || {}).cart || [];
  if (!text) bad(400, 'Empty transcript');
  let res = ruleParse(text, cart), engine = 'rules';
  if (process.env.ANTHROPIC_API_KEY) {
    try {
      const raw = await llmParse(text, cart); const clean = [];
      for (const a of raw || []) { try { clean.push(validateAction(a)); } catch (e) { /* drop invalid */ } }
      if (clean.length) {
        const lang = res.lang; res = { lang, actions: [], pending: [], reply: '', data: null, ui: null }; engine = 'llm+schema';
        for (const a of clean) {
          if (a.type === 'CLARIFY') { res.pending.push({ options: a.options, qty: a.qty, query: a.query }); res.reply += R(lang, a.options.length > 1 ? 'which' : 'howmany', { q: a.query, name: a.query }) + ' '; }
          else res.actions.push(a);
        }
        if (res.actions.some((a) => ['REPORT', 'GENERATE_REPORT'].includes(a.type))) res.ui = 'report';
        if (res.actions.some((a) => a.type === 'SHARE_INVOICE')) { res.ui = 'share'; res.reply = R(lang, 'share'); }
        if (res.actions.some((a) => a.type === 'CREATE_INVOICE')) { res.ui = cart.length ? 'finalize' : null; res.reply = R(lang, cart.length ? 'finalize' : 'empty'); }
        const adds = res.actions.filter((a) => a.type === 'ADD_ITEM');
        if (adds.length) res.reply = adds.map((a) => { const p = findProduct(a.productId); return R(lang, 'added', { name: (p.name + ' ' + p.variant).trim(), qty: a.qty }); }).join(' · ') + ' ' + res.reply;
      }
    } catch (e) { /* fall back to rules */ }
  }
  const valid = [];
  for (const a of res.actions) { try { valid.push(validateAction(a)); } catch (e) { /* dropped */ } }
  res.actions = valid; res.engine = engine;
  res.pending = res.pending.filter((p) => p.notFound || (p.options || []).every((id) => findProduct(id)));
  const lang = res.lang;
  const q2 = valid.find((a) => a.type === 'QUERY_SALES' || a.type === 'GENERATE_REPORT');
  if (q2) {
    const rep = buildReport(q2.range, q2.method); res.data = { report: rep, range: q2.range };
    const label = RLABEL[q2.range][LI[lang]] || RLABEL[q2.range][0];
    const amt = fmtP(q2.method ? rep.byMethod[q2.method] : rep.netPaise);
    res.reply = q2.type === 'GENERATE_REPORT' ? R(lang, 'report', { label }) : R(lang, 'sales', { label: label + (q2.method ? ' ' + q2.method.toUpperCase() : ''), amt, n: rep.invoiceCount }) + (q2.method ? ' (collected)' : '');
  }
  const cs = valid.find((a) => a.type === 'CHECK_STOCK');
  if (cs) {
    res.data = { stock: cs.productIds.map((id) => { const p = findProduct(id); return { id, name: (p.name + ' ' + p.variant).trim(), stock: p.stock, unit: p.unit, tracked: p.trackStock }; }) };
    res.reply = res.data.stock.map((s) => s.tracked ? R(lang, 'stock', { name: s.name, stock: s.stock + ' ' + s.unit }) : s.name + ': stock not tracked').join(' · ');
  }
  res.cart = applyActionsToCart(cart, valid);
  r.json(res);
}));

// Invoices
api.get('/invoices', (q, r) => {
  let list = db.invoices.filter((i) => (q.query.status ? i.status === q.query.status : i.status !== 'draft'));
  if (q.query.due === '1') list = list.filter((i) => i.status === 'final' && i.totals.grandPaise - i.paidPaise > 0);
  r.json(list.slice().sort((a, b) => b.createdAt - a.createdAt).slice(0, 300).map((i) => ({ ...i, cart: undefined })));
});
api.get('/invoices/:id', (q, r) => r.json(db.invoices.find((i) => i.id === q.params.id) || bad(404, 'Not found')));
api.post('/invoices', (q, r) => {
  const b = q.body || {};
  if (b.status === 'draft') {
    if (!Array.isArray(b.cart) || !b.cart.length) bad(400, 'Bill is empty');
    const totals = priceCart(b.cart, b.discountPaise);
    const inv = { id: uid('inv'), createdAt: Date.now(), status: 'draft', number: 'DRAFT', customer: b.customer || {}, cart: b.cart, lines: totals.lines, totals, paidPaise: 0, paymentStatus: 'unpaid', payments: [], returns: [], discountPaise: b.discountPaise || 0 };
    db.invoices.push(inv); audit('invoice.draft', inv.id); save(); return r.status(201).json(inv);
  }
  const out = finalizeInvoice(b); r.status(out.duplicate ? 200 : 201).json({ ...out.invoice, duplicate: out.duplicate });
});
api.post('/invoices/:id/finalize', (q, r) => {
  const inv = db.invoices.find((i) => i.id === q.params.id) || bad(404, 'Not found'); if (inv.status !== 'draft') bad(409, 'Only drafts can be finalized');
  const out = finalizeInvoice({ ...q.body, cart: inv.cart, discountPaise: inv.discountPaise, customer: (q.body && q.body.customer) || inv.customer }, inv); r.json(out.invoice);
});
api.delete('/invoices/:id/draft', (q, r) => { const i = db.invoices.findIndex((x) => x.id === q.params.id && x.status === 'draft'); if (i < 0) bad(404, 'Draft not found'); db.invoices.splice(i, 1); save(); r.json({ ok: true }); });
api.post('/invoices/:id/cancel', (q, r) => {
  const inv = db.invoices.find((i) => i.id === q.params.id) || bad(404, 'Not found');
  if (inv.status !== 'final') bad(409, 'Only finalized invoices can be cancelled');
  const reason = String((q.body || {}).reason || '').trim(); if (!reason) bad(400, 'A cancellation reason is required');
  const returned = {}; (inv.returns || []).forEach((rt) => rt.items.forEach((it) => { returned[it.productId] = (returned[it.productId] || 0) + it.qty; }));
  inv.lines.forEach((l) => moveStock(l.productId, l.qty - (returned[l.productId] || 0), 'cancel', inv.id));
  inv.status = 'cancelled'; inv.cancelReason = reason; inv.cancelledAt = Date.now();
  const refundable = inv.payments.filter((p) => p.status === 'received');
  refundable.forEach((p) => { p.status = 'refund_due'; });
  audit('invoice.cancel', inv.id, { reason, refundDuePaise: refundable.reduce((s, p) => s + p.amountPaise, 0) }); save(); r.json(inv);
});
api.post('/invoices/:id/return', (q, r) => {
  const inv = db.invoices.find((i) => i.id === q.params.id) || bad(404, 'Not found'); if (inv.status !== 'final') bad(409, 'Invoice is not active');
  const items = (q.body || {}).items || []; if (!items.length) bad(400, 'No items to return');
  let refund = 0; const rec = [];
  for (const it of items) {
    const l = inv.lines[it.lineIndex]; if (!l) bad(400, 'Bad line');
    const prev = (inv.returns || []).reduce((s, rt) => s + rt.items.filter((x) => x.productId === l.productId).reduce((a, x) => a + x.qty, 0), 0);
    const qty = Number(it.qty); if (!(qty > 0) || qty + prev > l.qty + 1e-9) bad(400, 'Return quantity exceeds sold quantity');
    const amt = Math.round((l.totalPaise * qtyMilli(qty)) / qtyMilli(l.qty)); refund += amt; rec.push({ productId: l.productId, name: l.name, qty, refundPaise: amt });
  }
  inv.returns = inv.returns || []; inv.returns.push({ id: uid('r'), at: Date.now(), reason: String((q.body || {}).reason || ''), items: rec, refundPaise: refund });
  rec.forEach((x) => moveStock(x.productId, x.qty, 'return', inv.id));
  audit('invoice.return', inv.id, { refund }); save(); r.json(inv);
});
api.get('/invoices/:id/pdf', wrap(async (q, r) => {
  const inv = db.invoices.find((i) => i.id === q.params.id) || bad(404, 'Not found');
  const buf = await renderPdf(inv); r.set({ 'Content-Type': 'application/pdf', 'Content-Disposition': `${q.query.download ? 'attachment' : 'inline'}; filename="${inv.number}.pdf"` }); r.send(buf);
}));
api.post('/invoices/:id/email', wrap(async (q, r) => {
  const inv = db.invoices.find((i) => i.id === q.params.id) || bad(404, 'Not found');
  const to = String((q.body || {}).to || inv.customer.email || '').trim(); if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)) bad(400, 'Enter a valid email address');
  if (!nodemailer || !process.env.SMTP_HOST) bad(501, 'Email is not configured on the server. Set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM.', { code: 'SMTP_NOT_CONFIGURED' });
  const tr = nodemailer.createTransport({ host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587), secure: process.env.SMTP_SECURE === '1', auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined });
  await tr.sendMail({ from: process.env.SMTP_FROM || process.env.SMTP_USER, to, subject: `Invoice ${inv.number} from ${db.settings.shopName}`, text: `Hello${inv.customer.name ? ' ' + inv.customer.name : ''},\n\nPlease find your invoice ${inv.number} for Rs. ${fmtP(inv.totals.grandPaise)} attached.\n\nThank you,\n${db.settings.shopName}`, attachments: [{ filename: inv.number + '.pdf', content: await renderPdf(inv) }] });
  audit('invoice.email', inv.id, { to }); save(); r.json({ ok: true });
}));

// Payments
api.get('/upi/qr', wrap(async (q, r) => {
  const amt = paise(q.query.amount || '0'); const inv = q.query.invoiceId ? db.invoices.find((i) => i.id === q.query.invoiceId) : null;
  const params = upiParams(amt, inv ? 'Invoice ' + inv.number : 'Payment', inv ? inv.number : undefined);
  r.json({ params, link: 'upi://pay?' + params, qr: await QRCode.toDataURL('upi://pay?' + params, { margin: 1, width: 320, color: { dark: '#0b0f24', light: '#ffffff' } }) });
}));
const METHODS = ['cash', 'upi', 'card'], APPS = ['gpay', 'phonepe', 'paytm', 'bhim', 'other'];
api.post('/payments', (q, r) => {
  const b = q.body || {}; const inv = db.invoices.find((i) => i.id === b.invoiceId) || bad(404, 'Invoice not found');
  if (inv.status !== 'final') bad(409, 'Invoice is not active');
  if (!METHODS.includes(b.method)) bad(400, 'Method must be cash, upi or card');
  const amt = paise(b.amount); if (amt <= 0) bad(400, 'Amount must be above zero');
  const due = inv.totals.grandPaise - inv.paidPaise; if (amt > due) bad(400, `Amount exceeds balance due (Rs. ${fmtP(due)})`);
  const ref = String(b.reference || '').trim().slice(0, 40);
  if (b.method === 'upi' && ref && db.payments.some((p) => p.method === 'upi' && p.reference === ref)) bad(409, 'This UPI transaction reference was already recorded');
  const pay = { id: uid('pay'), invoiceId: inv.id, invoiceNumber: inv.number, customer: inv.customer.name || '', at: Date.now(), method: b.method, app: b.method === 'upi' ? (APPS.includes(b.app) ? b.app : 'other') : null, amountPaise: amt, reference: ref, payerVpa: String(b.payerVpa || '').trim().slice(0, 60), status: 'received' };
  db.payments.push(pay); inv.payments.push(pay); inv.paidPaise += amt; inv.paymentStatus = paymentStatus(inv);
  audit('payment.record', pay.id, { amt, method: b.method }); save(); r.status(201).json({ payment: pay, invoice: { ...inv, cart: undefined } });
});
api.get('/payments', (q, r) => {
  const { method, from, to, q: s } = q.query; const t = String(s || '').toLowerCase();
  const list = db.payments.filter((p) => (!method || p.method === method) && (!from || dayKey(p.at) >= from) && (!to || dayKey(p.at) <= to) && (!t || (p.invoiceNumber + p.customer + p.reference + p.payerVpa).toLowerCase().includes(t))).sort((a, b) => b.at - a.at);
  const totals = { cash: 0, upi: 0, card: 0 }; list.filter((p) => p.status === 'received').forEach((p) => { totals[p.method] += p.amountPaise; });
  r.json({ payments: list.slice(0, 500), totals, count: list.length });
});

// Reports / audit
api.get('/reports', (q, r) => r.json(buildReport(RANGES.includes(q.query.range) ? q.query.range : 'today', null)));
api.get('/audit', (q, r) => r.json(db.audit.slice(-200).reverse()));

app.use('/api', (q, r) => r.status(404).json({ error: 'Not found' }));
app.use((err, q, r, n) => {
  if (err instanceof HttpError) return r.status(err.status).json({ error: err.message, ...err.extra });
  console.error(err); r.status(500).json({ error: 'Server error' });
});

if (require.main === module) readyP.then(() => app.listen(PORT, () => console.log(`Dayna AI running on http://localhost:${PORT} (${MONGO_URI ? 'MongoDB' : 'JSON file'} storage)`))).catch((e) => { console.error('Startup failed:', e.message); process.exit(1); });
module.exports = { app, paise, priceCart, ruleParse, validateAction };
