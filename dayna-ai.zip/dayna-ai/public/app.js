'use strict';
/* Dayna AI - frontend. Talks only to the REST API; totals always come from the server. */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (p) => '₹' + (Math.floor(p / 100)).toLocaleString('en-IN') + '.' + String(Math.abs(p) % 100).padStart(2, '0');
const toPaise = (s) => { s = String(s || '').trim(); if (!s) return 0; if (!/^\d+(\.\d{1,2})?$/.test(s)) return NaN; const [a, b = ''] = s.split('.'); return parseInt(a, 10) * 100 + parseInt((b + '00').slice(0, 2), 10); };
const rupees = (p) => (p / 100).toFixed(2);
const fmtDT = (t) => new Date(t).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
const debounce = (fn, ms = 250) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

async function api(path, opts = {}) {
  const o = { method: opts.method || 'GET', headers: {} };
  if (opts.body !== undefined) { o.headers['content-type'] = 'application/json'; o.body = JSON.stringify(opts.body); }
  const r = await fetch('/api' + path, o);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(data.error || 'Request failed'); e.status = r.status; e.data = data; throw e; }
  return data;
}
function toast(msg, type = 'ok') {
  const t = document.createElement('div'); t.className = 'toast ' + type; t.textContent = msg; $('#toasts').appendChild(t);
  setTimeout(() => { t.style.transition = '.4s'; t.style.opacity = 0; t.style.transform = 'translateX(60px)'; setTimeout(() => t.remove(), 400); }, 3800);
}
function modal(html, mount) {
  const bg = $('#modalBg'); $('#modal').innerHTML = html; bg.hidden = false;
  const close = () => { bg.hidden = true; $('#modal').innerHTML = ''; };
  bg.onclick = (e) => { if (e.target === bg) close(); };
  $$('[data-close]', bg).forEach((b) => (b.onclick = close));
  if (mount) mount(close);
  return close;
}
const state = { settings: {}, cart: [], priced: null, pending: [], lastInvoice: null, idem: crypto.randomUUID(), pay: { method: 'cash', app: '' }, dueInvoices: [], qr: null, range: 'today', products: [] };

/* ---------------------------------------------------------- background fx */
(function particles() {
  const c = $('#particles'), x = c.getContext('2d'); let W, H, pts = [];
  const rs = () => { W = c.width = innerWidth; H = c.height = innerHeight; pts = Array.from({ length: Math.min(60, Math.floor(W / 24)) }, () => ({ x: Math.random() * W, y: Math.random() * H, r: Math.random() * 1.8 + .4, vx: (Math.random() - .5) * .25, vy: -Math.random() * .35 - .05, a: Math.random() * .5 + .15 })); };
  rs(); addEventListener('resize', rs);
  (function tick() { x.clearRect(0, 0, W, H); for (const p of pts) { p.x += p.vx; p.y += p.vy; if (p.y < -5) { p.y = H + 5; p.x = Math.random() * W; } x.beginPath(); x.arc(p.x, p.y, p.r, 0, 7); x.fillStyle = `rgba(160,190,255,${p.a})`; x.fill(); } requestAnimationFrame(tick); })();
})();
document.addEventListener('mousemove', (e) => {
  const card = e.target.closest && e.target.closest('.tilt'); $$('.tilt').forEach((c) => { if (c !== card) c.style.transform = ''; });
  if (!card || matchMedia('(pointer:coarse)').matches) return; const b = card.getBoundingClientRect();
  const px = (e.clientX - b.left) / b.width - .5, py = (e.clientY - b.top) / b.height - .5;
  card.style.transform = `perspective(1100px) rotateX(${(-py * 2.2).toFixed(2)}deg) rotateY(${(px * 2.2).toFixed(2)}deg)`;
});
function countTo(el, target, fmt = money, ms = 600) {
  const from = Number(el.dataset.v || 0); el.dataset.v = target; const t0 = performance.now();
  (function step(t) { const k = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - k, 3); el.textContent = fmt(Math.round(from + (target - from) * e)); if (k < 1) requestAnimationFrame(step); })(t0);
}

/* ------------------------------------------------------------------ nav */
const TITLES = { billing: ['Voice Billing', 'Speak to bill. Confirm to finalize.'], payments: ['Payments', 'Collect via cash, GPay, PhonePe, Paytm or card — with QR scanner and history.'], invoices: ['Invoices', 'Download, print, share, return or cancel.'], reports: ['Reports', 'Sales, collections, top products and stock alerts.'], products: ['Products & stock', 'Catalogue, aliases, prices and inventory.'], settings: ['Settings', 'Shop, UPI, tax and inventory rules.'] };
function show(view) {
  $$('.nav button').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
  $$('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + view));
  $('#pageTitle').textContent = TITLES[view][0]; $('#shopLine').textContent = TITLES[view][1];
  scrollTo({ top: 0, behavior: 'smooth' });
  ({ payments: loadPayments, invoices: loadInvoices, reports: () => loadReport(state.range), products: loadProducts, settings: fillSettings, billing: loadDrafts })[view]();
}
$$('.nav button').forEach((b) => (b.onclick = () => show(b.dataset.view)));
async function refreshPill() { try { const r = await api('/reports?range=today'); $('#todayPill').textContent = 'Today ' + money(r.netPaise); } catch (e) { /* ignore */ } }

/* ---------------------------------------------------------------- billing */
async function refreshCart() {
  const disc = toPaise($('#billDisc').value);
  if (!state.cart.length) state.priced = null;
  else { try { state.priced = await api('/billing/preview', { method: 'POST', body: { cart: state.cart, discountPaise: isNaN(disc) ? 0 : disc } }); } catch (e) { toast(e.message, 'err'); state.cart = []; state.priced = null; } }
  renderCart();
}
function renderCart() {
  const P = state.priced, body = $('#cartBody'); body.innerHTML = '';
  $('#cartEmpty').hidden = !!(P && P.lines.length);
  (P ? P.lines : []).forEach((l, i) => {
    const c = state.cart[i]; const tr = document.createElement('tr'); tr.style.animationDelay = i * 40 + 'ms';
    tr.innerHTML = `<td><b>${esc(l.name)}</b><small>${esc(l.variant)} · ${esc(l.sku || '')}</small></td>
      <td class="num"><input type="number" min="0.001" step="any" value="${l.qty}" data-i="${i}" data-f="qty"> <small>${esc(l.unit)}</small></td>
      <td class="num">${money(l.unitPaise)}</td>
      <td class="num"><input type="text" inputmode="decimal" value="${l.discountPaise ? rupees(l.discountPaise) : ''}" placeholder="0" data-i="${i}" data-f="disc"></td>
      <td class="num"><b>${money(l.totalPaise)}</b></td><td><button class="x" data-rm="${i}" title="Remove">×</button></td>`;
    body.appendChild(tr);
  });
  const set = (id, v) => countTo($(id), v);
  set('#tSub', P ? P.grossPaise : 0); set('#tDisc', P ? P.lineDiscountPaise + P.invoiceDiscountPaise : 0); set('#tTax', P ? P.taxPaise : 0); set('#tGrand', P ? P.grandPaise : 0);
  $('#taxRow').style.display = P && P.taxEnabled ? '' : 'none'; $('#taxLbl').textContent = P && P.taxMode === 'inclusive' ? 'Tax (included)' : 'Tax';
  $('#finalize').disabled = !state.cart.length; $('#saveDraft').disabled = !state.cart.length;
}
$('#cartBody').addEventListener('change', (e) => {
  const i = e.target.dataset.i; if (i == null) return;
  if (e.target.dataset.f === 'qty') { const q = Number(e.target.value); if (q > 0) state.cart[i].qty = q; }
  else { const d = toPaise(e.target.value); if (isNaN(d)) return toast('Enter a valid discount', 'err'); state.cart[i].discountPaise = d; }
  refreshCart();
});
$('#cartBody').addEventListener('click', (e) => { const b = e.target.closest('[data-rm]'); if (b) { state.cart.splice(Number(b.dataset.rm), 1); refreshCart(); } });
$('#billDisc').addEventListener('input', debounce(refreshCart, 350));
$('#clearBill').onclick = () => { state.cart = []; state.pending = []; renderPending(); refreshCart(); };
async function applyActions(actions) { const r = await api('/cart/apply', { method: 'POST', body: { cart: state.cart, actions } }); state.cart = r.cart; await refreshCart(); }

/* pending clarifications (ambiguous product / missing quantity) */
async function renderPending() {
  const box = $('#pending'); box.innerHTML = ''; const p = state.pending[0]; if (!p) return;
  const div = document.createElement('div'); div.className = 'pend';
  if (p.notFound) {
    div.innerHTML = `<div class="q">Couldn't find “${esc(p.query)}” in your catalogue.</div><div class="opts"><button class="opt" data-dismiss>OK</button><button class="opt" data-addprod>+ Add it as a product</button></div>`;
  } else if (p.options.length > 1) {
    const prods = await Promise.all(p.options.map((id) => state.products.find((x) => x.id === id) || api('/products').then((l) => l.find((x) => x.id === id))));
    div.innerHTML = `<div class="q">Which ${esc(p.query)}${p.qty != null ? ' (×' + p.qty + ')' : ''}? ${p.mode === 'remove' ? '— remove which?' : ''}</div><div class="opts">${prods.filter(Boolean).map((x) => `<button class="opt" data-pick="${x.id}">${esc((x.name + ' ' + x.variant).trim())}<small>${money(x.pricePaise)}</small></button>`).join('')}</div>`;
  } else {
    div.innerHTML = `<div class="q">How many ${esc(p.query)}?</div><div class="opts">${[1, 2, 3, 4, 5, 6, 10, 12].map((n) => `<button class="opt" data-qty="${n}">${n}</button>`).join('')}<input id="qtyIn" type="number" min="1" placeholder="Other" style="width:90px"></div>`;
  }
  box.appendChild(div);
}
$('#pending').addEventListener('click', async (e) => {
  const p = state.pending[0]; if (!p) return;
  if (e.target.closest('[data-dismiss]')) { state.pending.shift(); return renderPending(); }
  if (e.target.closest('[data-addprod]')) { state.pending.shift(); renderPending(); show('products'); return openProductForm({ name: p.query }); }
  const pick = e.target.closest('[data-pick]'); if (pick) { p.options = [pick.dataset.pick]; if (p.mode === 'remove') { await applyActions([{ type: 'REMOVE_ITEM', productId: p.options[0] }]); state.pending.shift(); } return finishPending(); }
  const q = e.target.closest('[data-qty]'); if (q) { p.qty = Number(q.dataset.qty); return finishPending(); }
});
$('#pending').addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.id === 'qtyIn') { const n = Number(e.target.value); if (n > 0) { state.pending[0].qty = n; finishPending(); } } });
async function finishPending() {
  const p = state.pending[0];
  if (p && p.options.length === 1 && p.qty != null && !p.notFound) { try { await applyActions([{ type: 'ADD_ITEM', productId: p.options[0], qty: p.qty }]); toast('Added'); } catch (e) { toast(e.message, 'err'); } state.pending.shift(); }
  renderPending();
}

/* ------------------------------------------------------------------ voice */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
const V = { rec: null, listening: false, paused: false, finalText: '', interim: '', stream: null, analyser: null, level: 0 };
const EXAMPLES = ['Bhai, do Thums Up 750 ml, teen Bisleri ki bottle aur ek Sprite de do', 'Do Coke 750 ml add karo', 'Sprite ka stock kitna bacha hai?', 'Aaj ki sale kitni hui?', 'Aaj ki total cash sale batao', 'Pichhle hafte ka sales report dikhao', 'Last entry cancel karo', 'Bill banao', 'Is customer ka bill WhatsApp kar do'];
$('#examples').innerHTML = EXAMPLES.map((t) => `<button>${esc(t)}</button>`).join('');
$('#examples').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) { $('#typeCmd').value = b.textContent; processText(b.textContent); } });
function setTranscript() { const t = $('#transcript'); const txt = (V.finalText + ' ' + V.interim).trim(); t.innerHTML = txt ? `${esc(V.finalText)} <span class="interim">${esc(V.interim)}</span>` : '<span class="ph">Live transcript appears here…</span>'; }
function setMicUI(s) {
  $('#micWrap').classList.toggle('rec', s === 'rec'); $('#micWrap').classList.toggle('busy', s === 'busy');
  $('#pauseBtn').disabled = s !== 'rec' && !V.paused; $('#stopBtn').disabled = !(V.listening || V.paused);
  $('#pauseBtn').textContent = V.paused ? '▶ Resume' : '⏸ Pause';
  $('#micStatus').textContent = { rec: 'Listening… speak naturally', busy: 'Understanding…', idle: 'Tap the mic and speak', paused: 'Paused — tap Resume or Stop' }[s] || '';
}
function langCode() { const v = $('#langSel').value; return v === 'auto' ? 'en-IN' : v; }
async function startAudioMeter() {
  try {
    V.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
    const ac = new (window.AudioContext || window.webkitAudioContext)(); const src = ac.createMediaStreamSource(V.stream); V.analyser = ac.createAnalyser(); V.analyser.fftSize = 128; src.connect(V.analyser); V.ac = ac;
  } catch (e) { V.analyser = null; }
}
function stopAudioMeter() { if (V.stream) V.stream.getTracks().forEach((t) => t.stop()); V.stream = null; V.analyser = null; if (V.ac) V.ac.close().catch(() => {}); V.ac = null; }
function startRec(keep) {
  if (!SR) { toast('Speech recognition is not supported in this browser (use Chrome/Edge). You can type commands instead.', 'err'); $('#typeCmd').focus(); return; }
  if (!keep) { V.finalText = ''; V.interim = ''; setTranscript(); }
  const r = new SR(); r.lang = langCode(); r.continuous = true; r.interimResults = true; r.maxAlternatives = 1; V.rec = r; V.listening = true; V.paused = false;
  r.onresult = (e) => { let fin = '', im = ''; for (let i = e.resultIndex; i < e.results.length; i++) { const t = e.results[i][0].transcript; if (e.results[i].isFinal) fin += t + ' '; else im += t; } if (fin) V.finalText = (V.finalText + ' ' + fin).trim(); V.interim = im; setTranscript(); };
  r.onerror = (e) => { if (e.error === 'not-allowed' || e.error === 'service-not-allowed') { toast('Microphone permission denied. Allow mic access in the browser.', 'err'); V.listening = false; setMicUI('idle'); }
    else if (e.error === 'language-not-supported') { toast('This language is not supported for speech recognition here. Pick another language or type the command.', 'err'); V.listening = false; setMicUI('idle'); }
    else if (e.error === 'no-speech') { /* noisy / silent: restart handled in onend */ } else if (e.error !== 'aborted') toast('Speech error: ' + e.error + '. Tap Retry.', 'err'); };
  r.onend = () => { if (V.listening && !V.paused) { try { r.start(); } catch (e) { /* already started */ } } };
  try { r.start(); } catch (e) { /* ignore */ }
  startAudioMeter(); setMicUI('rec');
}
function stopRec() { V.listening = false; try { V.rec && V.rec.stop(); } catch (e) { /* noop */ } stopAudioMeter(); }
$('#micBtn').onclick = () => { if (V.listening) finishRec(); else startRec(V.paused); };
$('#pauseBtn').onclick = () => { if (V.paused) startRec(true); else { V.paused = true; stopRec(); setMicUI('paused'); } };
$('#stopBtn').onclick = finishRec;
$('#retryBtn').onclick = () => { stopRec(); V.paused = false; V.finalText = ''; V.interim = ''; setTranscript(); startRec(false); };
async function finishRec() { stopRec(); V.paused = false; const text = (V.finalText + ' ' + V.interim).trim(); V.interim = ''; if (!text) { setMicUI('idle'); return toast('Did not catch anything — try again closer to the mic.', 'err'); } await processText(text); }
$('#sendCmd').onclick = () => { const t = $('#typeCmd').value.trim(); if (t) processText(t); };
$('#typeCmd').addEventListener('keydown', (e) => { if (e.key === 'Enter') $('#sendCmd').click(); });

async function processText(text) {
  V.finalText = text; V.interim = ''; setTranscript(); setMicUI('busy');
  try {
    const r = await api('/voice/parse', { method: 'POST', body: { text, cart: state.cart } });
    state.cart = r.cart; state.pending = r.pending || []; await refreshCart(); renderPending();
    const a = $('#assistant'); a.hidden = false; a.innerHTML = `<small>${esc(r.lang === 'hinglish' ? 'Hinglish' : r.lang === 'hi' ? 'हिन्दी' : r.lang === 'or' ? 'ଓଡ଼ିଆ' : 'English')} · ${esc(r.engine)}</small><div>${esc(r.reply)}</div>`;
    speak(r.reply, r.lang);
    if (r.data && r.data.report && r.ui === 'report') { state.range = r.data.range; show('reports'); $$('#rangeSeg button').forEach((b) => b.classList.toggle('active', b.dataset.r === state.range)); }
    if (r.ui === 'share') { if (state.lastInvoice) shareModal(state.lastInvoice); else toast('Finalize a bill first, then share it.', 'err'); }
    if (r.ui === 'finalize') openConfirm();
  } catch (e) { toast(e.message, 'err'); } finally { setMicUI('idle'); }
}
function speak(text, lang) {
  if (!$('#ttsOn').checked || !window.speechSynthesis) return;
  const u = new SpeechSynthesisUtterance(text); u.lang = lang === 'or' ? 'or-IN' : lang === 'en' ? 'en-IN' : 'hi-IN'; u.rate = 1;
  speechSynthesis.cancel(); speechSynthesis.speak(u);
}
(function wave() {
  const c = $('#wave'), x = c.getContext('2d'); const W = c.width, H = c.height; let t = 0; const data = new Uint8Array(64);
  (function draw() {
    t += .05; x.clearRect(0, 0, W, H); const n = 48, bw = W / n; const g = x.createLinearGradient(0, 0, W, 0); g.addColorStop(0, '#7c5cff'); g.addColorStop(1, '#00d4ff'); x.fillStyle = g;
    if (V.analyser) V.analyser.getByteFrequencyData(data);
    for (let i = 0; i < n; i++) {
      let h; if (V.listening && V.analyser) h = 4 + (data[Math.floor(i * 1.1) % 64] / 255) * (H - 8); else if (V.listening) h = 6 + Math.abs(Math.sin(t * 2 + i * .5)) * 30; else h = 3 + (Math.sin(t + i * .35) + 1) * 3;
      const y = (H - h) / 2; x.globalAlpha = V.listening ? 1 : .45; x.beginPath(); x.roundRect ? x.roundRect(i * bw + 2, y, bw - 4, h, 3) : x.rect(i * bw + 2, y, bw - 4, h); x.fill();
    }
    requestAnimationFrame(draw);
  })();
})();

/* -------------------------------------------------------------- finalize */
function openConfirm() {
  if (!state.cart.length) return toast('The bill is empty', 'err'); const P = state.priced; if (!P) return;
  modal(`<h3>Confirm this bill?</h3><div class="table-wrap"><table><tbody>${P.lines.map((l) => `<tr><td>${esc(l.name)} <small>${esc(l.variant)}</small></td><td class="num">${l.qty} ${esc(l.unit)}</td><td class="num">${money(l.totalPaise)}</td></tr>`).join('')}</tbody></table></div>
    <div class="totals"><div class="grand"><span>Grand total</span><b>${money(P.grandPaise)}</b></div></div><p class="hint">Stock is updated only after you confirm.</p>
    <div class="actions"><button class="btn ghost" data-close>Back</button><button class="btn primary" id="okFin">Confirm &amp; finalize ✓</button></div>`, (close) => { $('#okFin').onclick = () => { close(); doFinalize(false); }; });
}
$('#finalize').onclick = openConfirm;
async function doFinalize(authorize) {
  const disc = toPaise($('#billDisc').value);
  try {
    const inv = await api('/invoices', { method: 'POST', body: { cart: state.cart, discountPaise: isNaN(disc) ? 0 : disc, customer: { name: $('#custName').value, phone: $('#custPhone').value }, idempotencyKey: state.idem, authorizeOverstock: !!authorize } });
    state.lastInvoice = inv; state.idem = crypto.randomUUID(); state.cart = []; state.pending = []; renderPending(); ['#custName', '#custPhone', '#billDisc'].forEach((s) => ($(s).value = '')); await refreshCart(); refreshPill();
    invoiceReady(inv);
  } catch (e) {
    if (e.status === 409 && e.data.code === 'INSUFFICIENT_STOCK') {
      modal(`<h3>⚠ Not enough stock</h3>${e.data.shortages.map((s) => `<p>${esc(s.name)} ${esc(s.variant)}: need <b>${s.requested}</b>, only <b>${s.available}</b> in stock</p>`).join('')}<p class="hint">Continue only if the stock count is wrong or you are sure you have the items.</p><div class="actions"><button class="btn ghost" data-close>Go back</button><button class="btn danger" id="authBtn">Authorize &amp; continue</button></div>`, (close) => { $('#authBtn').onclick = () => { close(); doFinalize(true); }; });
    } else toast(e.message, 'err');
  }
}
function invoiceReady(inv) {
  const due = inv.totals.grandPaise - inv.paidPaise;
  modal(`<div class="success">✅</div><h3 style="text-align:center">Invoice ${esc(inv.number)}</h3><p style="text-align:center" class="sub">Total <b style="color:#fff;font-size:20px">${money(inv.totals.grandPaise)}</b> · stock updated</p>
    <div class="actions" style="justify-content:center"><button class="btn primary" id="rdyPay">💳 Collect payment</button><a class="btn" href="/api/invoices/${inv.id}/pdf?download=1">⬇ PDF</a><button class="btn" id="rdyPrint">🖨 Print</button><button class="btn" id="rdyShare">↗ Share</button><button class="btn ghost" data-close>Done</button></div>`, (close) => {
    $('#rdyPay').onclick = () => { close(); state.preselect = inv.id; show('payments'); };
    $('#rdyPrint').onclick = () => printInvoice(inv); $('#rdyShare').onclick = () => { close(); shareModal(inv); };
  });
}
function printInvoice(inv) { const w = window.open('/api/invoices/' + inv.id + '/pdf', '_blank'); if (w) w.addEventListener('load', () => setTimeout(() => w.print(), 400)); else toast('Allow pop-ups to print', 'err'); }

/* drafts */
$('#saveDraft').onclick = async () => {
  const disc = toPaise($('#billDisc').value);
  try { await api('/invoices', { method: 'POST', body: { status: 'draft', cart: state.cart, discountPaise: isNaN(disc) ? 0 : disc, customer: { name: $('#custName').value, phone: $('#custPhone').value } } }); toast('Draft saved'); state.cart = []; await refreshCart(); loadDrafts(); } catch (e) { toast(e.message, 'err'); }
};
async function loadDrafts() {
  try { const d = await api('/invoices?status=draft'); $('#drafts').innerHTML = d.length ? '<small>Drafts:</small>' + d.map((x) => `<button class="opt" data-draft="${x.id}">${money(x.totals.grandPaise)}<small>${x.lines.length} items</small></button>`).join('') : ''; state.draftsData = d; } catch (e) { /* ignore */ }
}
$('#drafts').addEventListener('click', async (e) => {
  const b = e.target.closest('[data-draft]'); if (!b) return; const full = await api('/invoices/' + b.dataset.draft);
  state.cart = full.cart; $('#custName').value = full.customer.name || ''; $('#custPhone').value = full.customer.phone || ''; await api('/invoices/' + full.id + '/draft', { method: 'DELETE' }); await refreshCart(); loadDrafts(); toast('Draft loaded');
});

/* --------------------------------------------------------------- scanner */
async function openScanner(video, msgEl, onText) {
  let stop = false, stream = null;
  const halt = () => { stop = true; if (stream) stream.getTracks().forEach((t) => t.stop()); video.srcObject = null; };
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { msgEl.textContent = 'Camera needs HTTPS or localhost.'; return halt; }
  try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } } }); } catch (e) { msgEl.textContent = 'Camera permission denied or no camera found.'; return halt; }
  video.srcObject = stream; await video.play().catch(() => {});
  let detect;
  if ('BarcodeDetector' in window) { const d = new BarcodeDetector(); detect = async () => { const r = await d.detect(video); return r[0] && r[0].rawValue; }; }
  else {
    if (!window.jsQR) await new Promise((res, rej) => { const s = document.createElement('script'); s.src = '/vendor/jsQR.js'; s.onload = res; s.onerror = rej; document.head.appendChild(s); }).catch(() => { msgEl.textContent = 'Scanner library could not load (offline?). Enter details manually.'; });
    const cv = document.createElement('canvas'), cx = cv.getContext('2d', { willReadFrequently: true });
    detect = async () => { if (!window.jsQR || !video.videoWidth) return null; cv.width = video.videoWidth; cv.height = video.videoHeight; cx.drawImage(video, 0, 0); const im = cx.getImageData(0, 0, cv.width, cv.height); const q = window.jsQR(im.data, im.width, im.height); return q && q.data; };
  }
  (async function loop() { while (!stop) { try { const v = await detect(); if (v) { halt(); onText(v); return; } } catch (e) { /* keep scanning */ } await new Promise((r) => setTimeout(r, 220)); } })();
  return halt;
}
$('#scanProd').onclick = () => {
  let halt = () => {};
  modal(`<h3>Scan product barcode</h3><div class="scanner"><video id="pv" playsinline muted></video><div class="scan-frame"><i></i></div><div class="row between"><span class="hint" id="pm">Point at the barcode / QR (matches SKU)…</span></div></div><div class="actions"><button class="btn ghost" data-close>Close</button></div>`, async (close) => {
    $('#modalBg').onclick = (e) => { if (e.target.id === 'modalBg') { halt(); close(); } }; $$('[data-close]').forEach((b) => (b.onclick = () => { halt(); close(); }));
    halt = await openScanner($('#pv'), $('#pm'), async (code) => {
      close(); try { const p = await api('/products/barcode/' + encodeURIComponent(code)); await applyActions([{ type: 'ADD_ITEM', productId: p.id, qty: 1 }]); toast('Added ' + p.name + ' ' + p.variant); } catch (e) { toast(e.message + ' (' + code + ')', 'err'); }
    });
  });
};

/* --------------------------------------------------------------- sharing */
function shareModal(inv) {
  const link = location.origin + '/api/invoices/' + inv.id + '/pdf'; const local = /^(localhost|127\.|192\.168\.|10\.)/.test(location.hostname);
  modal(`<h3>Share ${esc(inv.number)}</h3>
    <label class="field">WhatsApp number<input id="shPhone" value="${esc(inv.customer.phone || '')}" placeholder="9876543210"></label>
    <label class="field">Email<input id="shMail" value="${esc(inv.customer.email || '')}" placeholder="customer@example.com"></label>
    ${local ? '<p class="hint warn">The invoice link only opens for the customer if this app is hosted online. For now, use “Share PDF” to attach the file directly.</p>' : ''}
    <div class="actions" style="justify-content:flex-start"><button class="btn primary" id="shWa">WhatsApp</button><button class="btn" id="shNative">Share PDF…</button><button class="btn" id="shEmail">Email</button><a class="btn" href="${link}?download=1">Download</a><button class="btn ghost" data-close>Close</button></div>`, () => {
    $('#shWa').onclick = () => { let n = $('#shPhone').value.replace(/\D/g, ''); if (n.length === 10) n = '91' + n; const msg = `Hello${inv.customer.name ? ' ' + inv.customer.name : ''}! Your bill ${inv.number} from ${state.settings.shopName} is ${money(inv.totals.grandPaise)}.${local ? '' : '\nInvoice: ' + link}`; window.open(`https://wa.me/${n}?text=${encodeURIComponent(msg)}`, '_blank'); };
    $('#shNative').onclick = async () => { try { const b = await (await fetch(link)).blob(); const f = new File([b], inv.number + '.pdf', { type: 'application/pdf' }); if (navigator.canShare && navigator.canShare({ files: [f] })) await navigator.share({ files: [f], title: inv.number }); else { toast('Native file sharing not supported here — downloading instead'); location.href = link + '?download=1'; } } catch (e) { if (e.name !== 'AbortError') toast(e.message, 'err'); } };
    $('#shEmail').onclick = async () => { const to = $('#shMail').value.trim(); try { await api('/invoices/' + inv.id + '/email', { method: 'POST', body: { to } }); toast('Email sent to ' + to); } catch (e) { if (e.status === 501) { toast('Server email not configured — opening your mail app', 'err'); location.href = `mailto:${to}?subject=${encodeURIComponent('Invoice ' + inv.number)}&body=${encodeURIComponent('Please find the invoice ' + inv.number + ' (' + money(inv.totals.grandPaise) + ').' + (local ? '' : '\n' + link))}`; } else toast(e.message, 'err'); } };
  });
}

/* --------------------------------------------------------------- payments */
async function loadPayments() { await loadDue(); await loadHistory(); }
async function loadDue() {
  state.dueInvoices = await api('/invoices?due=1'); const sel = $('#payInv');
  sel.innerHTML = state.dueInvoices.length ? state.dueInvoices.map((i) => `<option value="${i.id}">${esc(i.number)} · ${esc(i.customer.name || 'Walk-in')} · due ${money(i.totals.grandPaise - i.paidPaise)}</option>`).join('') : '<option value="">No invoices with balance due</option>';
  if (state.preselect && state.dueInvoices.some((i) => i.id === state.preselect)) sel.value = state.preselect; state.preselect = null; onInvChange();
}
function curInv() { return state.dueInvoices.find((i) => i.id === $('#payInv').value); }
function onInvChange() { const i = curInv(); const due = i ? i.totals.grandPaise - i.paidPaise : 0; countTo($('#dueAmt'), due); $('#payAmt').value = due ? rupees(due) : ''; $('#confirmPay').disabled = !i; refreshQR(); }
$('#payInv').onchange = onInvChange; $('#payAmt').addEventListener('input', debounce(refreshQR, 400));
$('#methods').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; $$('#methods button').forEach((x) => x.classList.toggle('active', x === b)); state.pay = { method: b.dataset.m, app: b.dataset.app }; syncMethodUI(); refreshQR(); });
function syncMethodUI() { const upi = state.pay.method === 'upi'; $('#upiPanel').hidden = !upi; $('#refFields').hidden = !upi; $('#confirmHint').hidden = state.pay.method === 'cash'; if (!upi) stopPayScan(); }
const SCHEMES = { gpay: 'tez://upi/pay?', phonepe: 'phonepe://pay?', paytm: 'paytmmp://pay?', bhim: 'upi://pay?', other: 'upi://pay?' };
async function refreshQR() {
  if (state.pay.method !== 'upi') return; const i = curInv(); const amt = toPaise($('#payAmt').value);
  if (!i || !amt || isNaN(amt)) { $('#qrImg').removeAttribute('src'); return; }
  try { const q = await api(`/upi/qr?invoiceId=${i.id}&amount=${rupees(amt)}`); state.qr = q; $('#qrImg').src = q.qr; $('#openApp').href = (SCHEMES[state.pay.app] || SCHEMES.other) + q.params; $('#upiHint').textContent = `Customer scans with any UPI app to pay ${money(amt)} to ${state.settings.upiId}. On a phone, tap “Open in app”.`; }
  catch (e) { $('#qrImg').removeAttribute('src'); $('#upiHint').innerHTML = esc(e.message) + ' — <a href="#" id="goSet">open Settings</a>'; const g = $('#goSet'); if (g) g.onclick = (ev) => { ev.preventDefault(); show('settings'); }; }
}
$('#copyUpi').onclick = async () => { if (!state.qr) return toast('No payment link yet', 'err'); try { await navigator.clipboard.writeText(state.qr.link); toast('UPI link copied'); } catch (e) { toast(state.qr.link); } };
let payHalt = null;
function stopPayScan() { if (payHalt) payHalt(); payHalt = null; $('#scannerBox').hidden = true; }
$('#scanPay').onclick = async () => {
  $('#scannerBox').hidden = false; $('#scanMsg').textContent = 'Point the camera at a UPI / payment QR…';
  payHalt = await openScanner($('#scanVideo'), $('#scanMsg'), (text) => {
    $('#scannerBox').hidden = true; payHalt = null;
    if (/^upi:\/\//i.test(text)) { const p = new URL(text.replace(/^upi:\/\//i, 'https://x/')).searchParams; const pa = p.get('pa'); if (pa) { $('#payVpa').value = pa; toast(`Scanned UPI ID: ${pa}${p.get('pn') ? ' (' + p.get('pn') + ')' : ''}`); } else toast('QR is a UPI link without an ID', 'err'); }
    else if (/^[A-Za-z0-9\-_.]{6,40}$/.test(text)) { $('#payRef').value = text; toast('Scanned reference: ' + text); }
    else toast('Scanned: ' + text.slice(0, 60));
  });
};
$('#scanStop').onclick = stopPayScan;
$('#confirmPay').onclick = async () => {
  const i = curInv(); if (!i) return; const amt = toPaise($('#payAmt').value); if (!amt || isNaN(amt)) return toast('Enter a valid amount', 'err');
  if (state.pay.method === 'upi' && !$('#payRef').value.trim() && !confirm('No UPI transaction ID entered. Record anyway? (Adding the UTR makes reconciliation easier.)')) return;
  try {
    const r = await api('/payments', { method: 'POST', body: { invoiceId: i.id, method: state.pay.method, app: state.pay.app, amount: rupees(amt), reference: $('#payRef').value, payerVpa: $('#payVpa').value } });
    toast(`${money(amt)} recorded · ${r.invoice.paymentStatus.toUpperCase()}`); state.lastInvoice = r.invoice; $('#payRef').value = ''; $('#payVpa').value = ''; stopPayScan(); await loadPayments(); refreshPill();
  } catch (e) { toast(e.message, 'err'); }
};
const APPN = { gpay: 'Google Pay', phonepe: 'PhonePe', paytm: 'Paytm', bhim: 'BHIM', other: 'UPI' };
async function loadHistory() {
  const q = new URLSearchParams(); [['method', '#fMethod'], ['from', '#fFrom'], ['to', '#fTo'], ['q', '#fSearch']].forEach(([k, s]) => { if ($(s).value) q.set(k, $(s).value); });
  const r = await api('/payments?' + q); state.payRows = r.payments;
  $('#payTotals').innerHTML = [['Cash', r.totals.cash, '#22c55e'], ['UPI', r.totals.upi, '#7c5cff'], ['Card', r.totals.card, '#00d4ff'], ['Total', r.totals.cash + r.totals.upi + r.totals.card, '#fff']].map(([l, v]) => `<div class="chip" style="border-left:3px solid ${l === 'Total' ? '#fff' : v === 0 ? 'transparent' : ''}">${l}<b data-v="0" class="cnt" data-t="${v}">${money(0)}</b></div>`).join('');
  $$('#payTotals .cnt').forEach((el) => countTo(el, Number(el.dataset.t)));
  $('#payBody').innerHTML = r.payments.map((p, i) => `<tr style="animation-delay:${Math.min(i, 12) * 30}ms"><td>${fmtDT(p.at)}</td><td>${esc(p.invoiceNumber)}<small>${esc(p.customer)}</small></td><td><span class="badge ${p.method}">${p.method === 'upi' ? esc(APPN[p.app] || 'UPI') : p.method.toUpperCase()}</span>${p.status !== 'received' ? ' <span class="badge ' + p.status + '">' + p.status.replace('_', ' ') + '</span>' : ''}</td><td class="num"><b>${money(p.amountPaise)}</b></td><td>${esc(p.reference || '—')}<small>${esc(p.payerVpa)}</small></td></tr>`).join('');
  $('#payEmpty').hidden = r.payments.length > 0;
}
['#fMethod', '#fFrom', '#fTo'].forEach((s) => ($(s).onchange = loadHistory)); $('#fSearch').addEventListener('input', debounce(loadHistory, 300));
$('#exportPay').onclick = () => {
  const rows = [['When', 'Invoice', 'Customer', 'Method', 'App', 'Amount', 'Reference', 'Payer UPI', 'Status'], ...(state.payRows || []).map((p) => [new Date(p.at).toISOString(), p.invoiceNumber, p.customer, p.method, p.app || '', rupees(p.amountPaise), p.reference, p.payerVpa, p.status])];
  const csv = rows.map((r) => r.map((c) => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\n'); const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'payments.csv'; a.click();
};

/* --------------------------------------------------------------- invoices */
async function loadInvoices() { state.invoices = await api('/invoices'); renderInvoices(); }
function renderInvoices() {
  const s = $('#invSearch').value.toLowerCase(); const list = (state.invoices || []).filter((i) => !s || (i.number + i.customer.name).toLowerCase().includes(s));
  $('#invBody').innerHTML = list.map((i, k) => { const due = i.totals.grandPaise - i.paidPaise; return `<tr style="animation-delay:${Math.min(k, 12) * 30}ms"><td><b>${esc(i.number)}</b></td><td>${fmtDT(i.finalizedAt || i.createdAt)}</td><td>${esc(i.customer.name || 'Walk-in')}</td><td class="num">${money(i.totals.grandPaise)}${(i.returns || []).length ? '<small>returns ' + money(i.returns.reduce((s, r) => s + r.refundPaise, 0)) + '</small>' : ''}</td>
    <td>${i.status === 'cancelled' ? '<span class="badge cancelled">cancelled</span>' : `<span class="badge ${i.paymentStatus}">${i.paymentStatus}</span>${due > 0 ? '<small>due ' + money(due) + '</small>' : ''}`}</td>
    <td style="white-space:nowrap"><a class="btn small ghost" href="/api/invoices/${i.id}/pdf" target="_blank">PDF</a> <button class="btn small ghost" data-share="${i.id}">Share</button>${i.status === 'final' ? ` ${due > 0 ? `<button class="btn small" data-pay="${i.id}">Pay</button>` : ''} <button class="btn small ghost" data-ret="${i.id}">Return</button> <button class="btn small danger" data-can="${i.id}">Cancel</button>` : ''}</td></tr>`; }).join('');
  $('#invEmpty').hidden = list.length > 0;
}
$('#invSearch').addEventListener('input', renderInvoices);
$('#invBody').addEventListener('click', async (e) => {
  const b = e.target.closest('button'); if (!b) return; const id = b.dataset.share || b.dataset.pay || b.dataset.ret || b.dataset.can; const inv = state.invoices.find((i) => i.id === id);
  if (b.dataset.share) shareModal(inv);
  if (b.dataset.pay) { state.preselect = id; show('payments'); }
  if (b.dataset.can) modal(`<h3>Cancel ${esc(inv.number)}?</h3><p class="hint">Stock is restored and the cancellation is logged. Payments received are marked “refund due”.</p><label class="field">Reason (required)<input id="cReason"></label><div class="actions"><button class="btn ghost" data-close>Keep invoice</button><button class="btn danger" id="cOk">Cancel invoice</button></div>`, (close) => { $('#cOk').onclick = async () => { try { await api(`/invoices/${id}/cancel`, { method: 'POST', body: { reason: $('#cReason').value } }); close(); toast('Invoice cancelled'); loadInvoices(); refreshPill(); } catch (er) { toast(er.message, 'err'); } }; });
  if (b.dataset.ret) modal(`<h3>Return items — ${esc(inv.number)}</h3>${inv.lines.map((l, k) => `<div class="row between" style="margin:8px 0"><span>${esc(l.name)} ${esc(l.variant)} <small>sold ${l.qty}</small></span><input type="number" min="0" max="${l.qty}" step="any" value="0" data-l="${k}" style="width:90px"></div>`).join('')}<label class="field">Reason<input id="rReason"></label><div class="actions"><button class="btn ghost" data-close>Close</button><button class="btn primary" id="rOk">Record return</button></div>`, (close) => {
    $('#rOk').onclick = async () => { const items = $$('[data-l]').map((x) => ({ lineIndex: Number(x.dataset.l), qty: Number(x.value) })).filter((x) => x.qty > 0); try { const r = await api(`/invoices/${id}/return`, { method: 'POST', body: { items, reason: $('#rReason').value } }); close(); toast('Return recorded · refund ' + money(r.returns[r.returns.length - 1].refundPaise)); loadInvoices(); refreshPill(); } catch (er) { toast(er.message, 'err'); } }; });
});

/* ---------------------------------------------------------------- reports */
$('#rangeSeg').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; state.range = b.dataset.r; $$('#rangeSeg button').forEach((x) => x.classList.toggle('active', x === b)); loadReport(state.range); });
async function loadReport(range) {
  const r = await api('/reports?range=' + range);
  const K = [['Net sales', r.netPaise, '#7c5cff'], ['Invoices', r.invoiceCount, '#00d4ff', true], ['Collected', r.collectedPaise, '#22c55e'], ['Outstanding (credit)', r.outstandingPaise, '#f59e0b'], ['Discounts given', r.discountPaise, '#d946ef'], ['Returns', r.returnsPaise, '#ef4444']];
  $('#kpis').innerHTML = K.map(([l, v, c, plain], i) => `<div class="kpi" style="--c:${c};animation-delay:${i * 70}ms"><span>${l}</span><b class="cnt" data-v="0" data-t="${v}" data-plain="${plain ? 1 : ''}">0</b></div>`).join('');
  $$('#kpis .cnt').forEach((el) => countTo(el, Number(el.dataset.t), el.dataset.plain ? (n) => String(n) : money));
  drawBars(r.series); drawDonut(r.byMethod);
  const max = Math.max(1, ...r.top.map((t) => t.amountPaise));
  $('#topList').innerHTML = r.top.length ? r.top.map((t) => `<div class="bar-row"><div class="lbl"><span>${esc(t.name)} <small>×${t.qty}</small></span><b>${money(t.amountPaise)}</b></div><div class="bar-track"><div class="bar-fill" data-w="${(t.amountPaise / max) * 100}"></div></div></div>`).join('') : '<div class="empty">No sales in this period.</div>';
  $('#lowList').innerHTML = r.lowStock.length ? r.lowStock.map((t) => `<div class="bar-row"><div class="lbl"><span>${esc(t.name)}</span><b>${t.stock} left <small>(alert ≤ ${t.lowStock})</small></b></div><div class="bar-track"><div class="bar-fill warn" data-w="${Math.min(100, (t.stock / Math.max(1, t.lowStock)) * 60 + 5)}"></div></div></div>`).join('') : '<div class="empty">All tracked items are above their low-stock threshold ✅</div>';
  requestAnimationFrame(() => setTimeout(() => $$('.bar-fill').forEach((b) => (b.style.width = b.dataset.w + '%')), 60));
}
function fitCanvas(c, h) { const d = devicePixelRatio || 1, w = c.clientWidth; c.width = w * d; c.height = h * d; const x = c.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0); return { x, w, h }; }
function drawBars(series) {
  const c = $('#barChart'), { x, w, h } = fitCanvas(c, 260); const pad = { l: 8, r: 8, t: 26, b: 28 }; const max = Math.max(100, ...series.map((s) => s.totalPaise)); const n = series.length || 1; const bw = Math.min(46, (w - pad.l - pad.r) / n * .62); const t0 = performance.now();
  (function frame(t) {
    const k = Math.min(1, (t - t0) / 900), e = 1 - Math.pow(1 - k, 3); x.clearRect(0, 0, w, h);
    x.strokeStyle = 'rgba(255,255,255,.07)'; for (let i = 0; i <= 4; i++) { const y = pad.t + ((h - pad.t - pad.b) * i) / 4; x.beginPath(); x.moveTo(pad.l, y); x.lineTo(w - pad.r, y); x.stroke(); }
    series.forEach((s, i) => {
      const cx = pad.l + ((w - pad.l - pad.r) / n) * (i + .5), bh = ((s.totalPaise / max) * (h - pad.t - pad.b)) * e, y = h - pad.b - bh;
      const g = x.createLinearGradient(0, y, 0, h - pad.b); g.addColorStop(0, '#00d4ff'); g.addColorStop(1, '#7c5cff'); x.fillStyle = g; x.beginPath(); x.roundRect ? x.roundRect(cx - bw / 2, y, bw, Math.max(bh, 1), 6) : x.rect(cx - bw / 2, y, bw, bh); x.fill();
      x.fillStyle = '#9aa5c4'; x.font = '11px system-ui'; x.textAlign = 'center'; if (n <= 14 || i % Math.ceil(n / 10) === 0) x.fillText(s.date.slice(5), cx, h - 8);
      if (s.totalPaise > 0 && k > .8 && n <= 10) { x.fillStyle = '#e8ecf8'; x.fillText('₹' + Math.round(s.totalPaise / 100).toLocaleString('en-IN'), cx, y - 6); }
    });
    if (k < 1) requestAnimationFrame(frame);
  })(t0);
}
function drawDonut(m) {
  const c = $('#donut'), x = c.getContext('2d'), cs = [['Cash', m.cash, '#22c55e'], ['UPI', m.upi, '#7c5cff'], ['Card', m.card, '#00d4ff']]; const tot = cs.reduce((s, a) => s + a[1], 0); const t0 = performance.now();
  $('#donutLegend').innerHTML = cs.map(([l, v, col]) => `<div><i style="background:${col}"></i>${l} <b>${money(v)}</b></div>`).join('');
  (function frame(t) {
    const k = Math.min(1, (t - t0) / 1000), e = 1 - Math.pow(1 - k, 3); x.clearRect(0, 0, 220, 220); let a = -Math.PI / 2;
    if (!tot) { x.strokeStyle = 'rgba(255,255,255,.1)'; x.lineWidth = 26; x.beginPath(); x.arc(110, 110, 80, 0, 7); x.stroke(); }
    cs.forEach(([, v, col]) => { const ang = (v / (tot || 1)) * Math.PI * 2 * e; x.strokeStyle = col; x.lineWidth = 26; x.lineCap = 'butt'; x.beginPath(); x.arc(110, 110, 80, a, a + ang); x.stroke(); a += ang; });
    x.fillStyle = '#e8ecf8'; x.textAlign = 'center'; x.font = '700 20px system-ui'; x.fillText(money(Math.round(tot * e)), 110, 112); x.font = '12px system-ui'; x.fillStyle = '#9aa5c4'; x.fillText('collected', 110, 132);
    if (k < 1) requestAnimationFrame(frame);
  })(t0);
}
addEventListener('resize', debounce(() => { if ($('#view-reports').classList.contains('active')) loadReport(state.range); }, 300));

/* --------------------------------------------------------------- products */
async function loadProducts() {
  const q = encodeURIComponent($('#prodSearch').value); const list = await api(`/products?q=${q}&archived=${$('#showArch').checked ? 1 : 0}`); state.products = list;
  $('#sampleNote').textContent = list.some((p) => p.sample) ? 'Sample catalogue loaded for demo — edit prices and products to match your shop before billing real customers.' : '';
  $('#prodBody').innerHTML = list.map((p, i) => `<tr style="animation-delay:${Math.min(i, 14) * 25}ms"><td><b>${esc(p.name)}</b> <small>${esc(p.variant)}${p.brand ? ' · ' + esc(p.brand) : ''}</small><small>${esc((p.aliases || []).join(', '))}</small></td><td>${esc(p.sku || '—')}</td><td>${esc(p.unit)}</td><td class="num">${money(p.pricePaise)}</td><td class="num">${money(p.costPaise || 0)}</td>
    <td class="num">${p.trackStock ? `<span class="badge ${p.stock <= p.lowStock ? 'unpaid' : 'paid'}">${p.stock}</span>` : '<small>not tracked</small>'}</td><td style="white-space:nowrap"><button class="btn small ghost" data-edit="${p.id}">Edit</button> <button class="btn small ghost" data-hist="${p.id}">Stock log</button> <button class="btn small ghost" data-arch="${p.id}">${p.archived ? 'Restore' : 'Archive'}</button></td></tr>`).join('');
}
$('#prodSearch').addEventListener('input', debounce(loadProducts)); $('#showArch').onchange = loadProducts;
$('#addProd').onclick = () => openProductForm();
function openProductForm(p) {
  p = p || {}; const ed = !!p.id;
  modal(`<h3>${ed ? 'Edit' : 'Add'} product</h3><div class="grid-2 tight"><label class="field">Name<input id="pName" value="${esc(p.name || '')}"></label><label class="field">Brand<input id="pBrand" value="${esc(p.brand || '')}"></label>
    <label class="field">SKU / barcode<input id="pSku" value="${esc(p.sku || '')}"></label><label class="field">Unit<input id="pUnit" value="${esc(p.unit || 'piece')}" list="units"></label>
    <label class="field">Size (number)<input id="pSize" value="${p.sizeVal || ''}" placeholder="750"></label><label class="field">Size unit<select id="pSizeU"><option value="">—</option>${['ml', 'l', 'g', 'kg'].map((u) => `<option ${p.sizeUnit === u ? 'selected' : ''}>${u}</option>`).join('')}</select></label>
    <label class="field">Selling price ₹<input id="pPrice" value="${p.pricePaise != null ? rupees(p.pricePaise) : ''}" inputmode="decimal"></label><label class="field">Cost ₹<input id="pCost" value="${p.costPaise ? rupees(p.costPaise) : ''}" inputmode="decimal"></label>
    <label class="field">${ed ? 'Stock' : 'Opening stock'}<input id="pStock" value="${p.stock != null ? p.stock : ''}" inputmode="decimal"></label><label class="field">Low-stock alert at<input id="pLow" value="${p.lowStock != null ? p.lowStock : 5}"></label>
    <label class="field">Tax % <small>(blank = shop default)</small><input id="pTax" value="${p.taxRate != null ? p.taxRate : ''}"></label><label class="switch block"><input type="checkbox" id="pTrack" ${p.trackStock === false ? '' : 'checked'}><span></span> Track stock</label></div>
    <label class="field">Spoken names / aliases <small>(comma separated — how people say it: coke, कोक, ...)</small><input id="pAlias" value="${esc((p.aliases || []).join(', '))}"></label>
    <datalist id="units">${['piece', 'bottle', 'can', 'pack', 'carton', 'kg', 'g', 'litre', 'ml', 'cup'].map((u) => `<option>${u}</option>`).join('')}</datalist>
    <div class="actions"><button class="btn ghost" data-close>Cancel</button><button class="btn primary" id="pSave">Save</button></div>`, (close) => {
    $('#pSave').onclick = async () => { const body = { name: $('#pName').value, brand: $('#pBrand').value, sku: $('#pSku').value, unit: $('#pUnit').value, sizeVal: $('#pSize').value, sizeUnit: $('#pSizeU').value, price: $('#pPrice').value, cost: $('#pCost').value, stock: $('#pStock').value, lowStock: $('#pLow').value, taxRate: $('#pTax').value, trackStock: $('#pTrack').checked, aliases: $('#pAlias').value };
      try { await api(ed ? '/products/' + p.id : '/products', { method: ed ? 'PUT' : 'POST', body }); close(); toast('Saved'); loadProducts(); } catch (e) { toast(e.message, 'err'); } };
  });
}
$('#prodBody').addEventListener('click', async (e) => {
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.edit) openProductForm(state.products.find((p) => p.id === b.dataset.edit));
  if (b.dataset.arch) { await api('/products/' + b.dataset.arch, { method: 'DELETE' }); loadProducts(); }
  if (b.dataset.hist) { const m = await api(`/products/${b.dataset.hist}/movements`); modal(`<h3>Stock movements</h3><div class="table-wrap tall"><table><thead><tr><th>When</th><th>Reason</th><th class="num">Change</th><th class="num">Balance</th></tr></thead><tbody>${m.map((x) => `<tr><td>${fmtDT(x.at)}</td><td>${esc(x.reason)}</td><td class="num" style="color:${x.delta < 0 ? '#ff8a8a' : '#5fe08a'}">${x.delta > 0 ? '+' : ''}${x.delta}</td><td class="num">${x.balance}</td></tr>`).join('') || '<tr><td colspan=4 class="empty">No movements yet</td></tr>'}</tbody></table></div><div class="actions"><button class="btn ghost" data-close>Close</button></div>`); }
});
$('#importBtn').onclick = () => $('#csvFile').click();
$('#csvFile').onchange = async (e) => { const f = e.target.files[0]; if (!f) return; try { const r = await api('/products/import', { method: 'POST', body: { csv: await f.text() } }); toast(`Imported: ${r.created} new, ${r.updated} updated${r.errors.length ? ', ' + r.errors.length + ' rows skipped (row ' + r.errors.map((x) => x.row).join(', ') + ')' : ''}`, r.errors.length ? 'err' : 'ok'); loadProducts(); } catch (er) { toast(er.message + ' — columns: name,brand,sku,size,unit,price,cost,stock,lowStock,taxRate,aliases', 'err'); } e.target.value = ''; };

/* --------------------------------------------------------------- settings */
async function fillSettings() {
  const s = state.settings = await api('/settings');
  const m = { '#sShop': s.shopName, '#sPhone': s.phone, '#sAddr': s.address, '#sEmail': s.email, '#sGstin': s.gstin, '#sUpi': s.upiId, '#sUpiName': s.upiName, '#sTaxMode': s.taxMode, '#sTaxRate': s.defaultTaxRate, '#sPrefix': s.invoicePrefix };
  Object.entries(m).forEach(([k, v]) => ($(k).value = v == null ? '' : v)); $('#sTaxOn').checked = s.taxEnabled; $('#sTrack').checked = s.trackStock;
  $('#logoPrev').innerHTML = s.logo ? `<img src="${s.logo}" alt="logo">` : '';
  $('#integrations').innerHTML = `AI provider: <b>${s.llm ? 'Claude (set via ANTHROPIC_API_KEY) + schema validation' : 'built-in rules parser (set ANTHROPIC_API_KEY for deeper language understanding)'}</b><br>Email: <b>${s.smtp ? 'SMTP configured' : 'not configured (set SMTP_* env vars) — mail app fallback used'}</b>`;
}
$('#sLogo').onchange = (e) => { const f = e.target.files[0]; if (!f) return; if (f.size > 300000) { toast('Logo must be under 300 KB', 'err'); return; } const r = new FileReader(); r.onload = () => { state.newLogo = r.result; $('#logoPrev').innerHTML = `<img src="${r.result}">`; }; r.readAsDataURL(f); };
$('#saveSettings').onclick = async () => {
  const body = { shopName: $('#sShop').value, phone: $('#sPhone').value, address: $('#sAddr').value, email: $('#sEmail').value, gstin: $('#sGstin').value, upiId: $('#sUpi').value, upiName: $('#sUpiName').value, taxEnabled: $('#sTaxOn').checked, taxMode: $('#sTaxMode').value, defaultTaxRate: $('#sTaxRate').value || 0, trackStock: $('#sTrack').checked, invoicePrefix: $('#sPrefix').value };
  if (state.newLogo) body.logo = state.newLogo;
  try { state.settings = await api('/settings', { method: 'PUT', body }); state.newLogo = null; toast('Settings saved'); refreshCart(); document.title = state.settings.shopName + ' · Dayna AI'; } catch (e) { toast(e.message, 'err'); }
};

/* ------------------------------------------------------------------- boot */
(async function init() {
  try { state.settings = await api('/settings'); state.products = await api('/products'); document.title = state.settings.shopName + ' · Dayna AI'; } catch (e) { toast('Cannot reach the server: ' + e.message, 'err'); }
  renderCart(); loadDrafts(); refreshPill(); setMicUI('idle'); if (!SR) $('#micStatus').textContent = 'Voice needs Chrome/Edge — you can still type commands';
  if (!state.settings.upiId) setTimeout(() => toast('Tip: add your UPI ID in Settings to enable GPay / PhonePe / Paytm QR payments.'), 1500);
})();
