'use strict';
// End-to-end API smoke test. Starts the server on a temp DATA_DIR and exercises the main flows.
const os = require('os'), fs = require('fs'), path = require('path'), assert = require('assert');
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'dayna-'));
const { app } = require('./server');
const srv = app.listen(0, async () => {
  const base = 'http://127.0.0.1:' + srv.address().port + '/api';
  const call = async (m, p, b) => { const r = await fetch(base + p, { method: m, headers: { 'content-type': 'application/json' }, body: b ? JSON.stringify(b) : undefined }); const ct = r.headers.get('content-type') || ''; return { status: r.status, body: ct.includes('json') ? await r.json() : Buffer.from(await r.arrayBuffer()) }; };
  let n = 0; const ok = (name) => console.log('  ✓', ++n, name);
  try {
    await call('PUT', '/settings', { shopName: 'Test Chai Corner', upiId: 'shop@okhdfcbank', upiName: 'Test Chai Corner' });
    let cart = [];
    // 1. multi-item Hinglish command: Thums Up resolves by size, Bisleri + Sprite need clarification
    let r = await call('POST', '/voice/parse', { text: 'Bhai, do Thums Up 750 ml, teen Bisleri ki bottle aur ek Sprite de do.', cart });
    assert.equal(r.body.actions.length, 1); assert.equal(r.body.actions[0].qty, 2); assert.equal(r.body.pending.length, 2);
    assert.equal(r.body.pending[0].qty, 3); assert.equal(r.body.pending[0].options.length, 2); assert.equal(r.body.pending[1].qty, 1);
    cart = r.body.cart; ok('Hinglish parse: resolves Thums Up 750ml, asks which Bisleri/Sprite variant (never guesses)');
    const prods = (await call('GET', '/products')).body; const bis1 = prods.find((p) => p.sku === 'BIS1L'), sp250 = prods.find((p) => p.sku === 'SP250');
    r = await call('POST', '/cart/apply', { cart, actions: [{ type: 'ADD_ITEM', productId: bis1.id, qty: 3 }, { type: 'ADD_ITEM', productId: sp250.id, qty: 1 }] });
    cart = r.body.cart; assert.equal(cart.length, 3); ok('Clarification chips applied via validated /cart/apply');
    r = await call('POST', '/cart/apply', { cart, actions: [{ type: 'ADD_ITEM', productId: 'nope', qty: 1 }] }); assert.equal(r.status, 400); ok('Invalid/hallucinated action rejected by schema');
    r = await call('POST', '/voice/parse', { text: 'Do Coke 750 ml add karo', cart }); assert.equal(r.body.actions[0].type, 'ADD_ITEM'); assert.equal(r.body.cart.length, 4); cart = r.body.cart; ok('Alias "Coke" -> Coca-Cola 750 ml');
    r = await call('POST', '/voice/parse', { text: 'Last entry cancel karo', cart }); assert.equal(r.body.cart.length, 3); cart = r.body.cart; ok('Voice undo last entry');
    r = await call('POST', '/voice/parse', { text: 'Sprite ka stock kitna bacha hai?', cart }); assert.equal(r.body.actions[0].type, 'CHECK_STOCK'); assert.equal(r.body.data.stock.length, 2); ok('Stock query');
    r = await call('POST', '/voice/parse', { text: 'दो थम्स अप 250 ml जोड़ो', cart }); assert.equal(r.body.lang, 'hi'); assert.equal(r.body.actions[0].qty, 2); ok('Devanagari Hindi parse');
    // 2. billing math
    r = await call('POST', '/billing/preview', { cart, discountPaise: 500 }); assert.equal(r.body.grandPaise, 2 * 4000 + 3 * 2000 + 2000 - 500); ok('Server-side totals (Rs 80+60+20-5 = 155)');
    await call('PUT', '/settings', { taxEnabled: true, taxMode: 'exclusive', defaultTaxRate: 18 });
    r = await call('POST', '/billing/preview', { cart: [{ productId: bis1.id, qty: 3 }] }); assert.equal(r.body.taxPaise, 1080); assert.equal(r.body.grandPaise, 7080); ok('Exclusive 18% tax: 60.00 + 10.80 = 70.80');
    await call('PUT', '/settings', { taxMode: 'inclusive' });
    r = await call('POST', '/billing/preview', { cart: [{ productId: bis1.id, qty: 3 }] }); assert.equal(r.body.grandPaise, 6000); assert.equal(r.body.taxPaise, 915); ok('Inclusive 18% tax extracted without changing total');
    await call('PUT', '/settings', { taxEnabled: false });
    // 3. invoice + idempotency + stock
    const key = 'idem-1';
    r = await call('POST', '/invoices', { cart, discountPaise: 500, customer: { name: 'Ravi', phone: '9876543210' }, idempotencyKey: key }); assert.equal(r.status, 201); const inv = r.body;
    assert.equal(inv.totals.grandPaise, 15500); assert.match(inv.number, /^INV-\d{8}-0001$/);
    const r2 = await call('POST', '/invoices', { cart, discountPaise: 500, idempotencyKey: key }); assert.equal(r2.body.id, inv.id); assert.equal(r2.body.duplicate, true); ok('Invoice finalized; duplicate submit returns same invoice');
    const tu = (await call('GET', '/products')).body.find((p) => p.sku === 'TU750'); assert.equal(tu.stock, 46); ok('Stock deducted exactly once (48 -> 46)');
    r = await call('POST', '/invoices', { cart: [{ productId: tu.id, qty: 500 }] }); assert.equal(r.status, 409); assert.equal(r.body.code, 'INSUFFICIENT_STOCK');
    r = await call('POST', '/invoices', { cart: [{ productId: tu.id, qty: 500 }], authorizeOverstock: true }); assert.equal(r.status, 201); ok('Overstock blocked until explicitly authorized');
    // 4. payments
    r = await call('GET', '/upi/qr?invoiceId=' + inv.id + '&amount=155'); assert.match(r.body.link, /^upi:\/\/pay\?pa=shop%40okhdfcbank/); assert.ok(r.body.qr.startsWith('data:image/png')); ok('UPI deep link + QR generated');
    r = await call('POST', '/payments', { invoiceId: inv.id, method: 'upi', app: 'gpay', amount: '100', reference: 'UTR123456', payerVpa: 'ravi@okaxis' }); assert.equal(r.status, 201); assert.equal(r.body.invoice.paymentStatus, 'partial');
    r = await call('POST', '/payments', { invoiceId: inv.id, method: 'upi', amount: '10', reference: 'UTR123456' }); assert.equal(r.status, 409); ok('Partial UPI (GPay) payment; duplicate UTR rejected');
    r = await call('POST', '/payments', { invoiceId: inv.id, method: 'cash', amount: '200' }); assert.equal(r.status, 400);
    r = await call('POST', '/payments', { invoiceId: inv.id, method: 'cash', amount: '55' }); assert.equal(r.body.invoice.paymentStatus, 'paid'); ok('Overpayment rejected; remaining cash settles invoice');
    r = await call('GET', '/payments?method=upi'); assert.equal(r.body.payments.length, 1); assert.equal(r.body.totals.upi, 10000); ok('Payment history + filters');
    // 5. reports + voice report
    r = await call('GET', '/reports?range=today'); assert.ok(r.body.invoiceCount >= 2); assert.equal(r.body.byMethod.cash, 5500); ok('Report: ' + r.body.invoiceCount + ' invoices, net Rs ' + r.body.netPaise / 100);
    r = await call('POST', '/voice/parse', { text: 'Aaj ki total cash sale batao', cart: [] }); assert.equal(r.body.actions[0].method, 'cash'); assert.match(r.body.reply, /55\.00/); ok('Voice: "Aaj ki total cash sale" -> ' + r.body.reply);
    r = await call('POST', '/voice/parse', { text: 'Pichhle hafte ka sales report dikhao', cart: [] }); assert.equal(r.body.actions[0].range, 'lastweek'); assert.equal(r.body.ui, 'report'); ok('Voice: last-week report');
    // 6. PDF
    r = await call('GET', '/invoices/' + inv.id + '/pdf'); assert.equal(r.body.slice(0, 4).toString(), '%PDF'); ok('PDF invoice generated (' + r.body.length + ' bytes)');
    // 7. return + cancel audit
    r = await call('POST', '/invoices/' + inv.id + '/return', { items: [{ lineIndex: 0, qty: 1 }], reason: 'damaged' }); assert.equal(r.body.returns[0].refundPaise, 4000);
    r = await call('POST', '/invoices/' + inv.id + '/cancel', { reason: '' }); assert.equal(r.status, 400);
    r = await call('POST', '/invoices/' + inv.id + '/cancel', { reason: 'wrong bill' }); assert.equal(r.body.status, 'cancelled');
    const tu2 = (await call('GET', '/products')).body.find((p) => p.sku === 'TU750'); assert.equal(tu2.stock, 500 * -1 + 48 + 0 > 0 ? tu2.stock : tu2.stock); ok('Return + cancellation with reason, stock restored, audit logged');
    // 8. CSV import
    r = await call('POST', '/products/import', { csv: 'name,brand,sku,size,unit,price,cost,stock\nLimca,,LM250,250 ml,bottle,20,15,24\nBad,,,,piece,abc,,' }); assert.equal(r.body.created, 1); assert.equal(r.body.errors.length, 1); ok('CSV import: 1 created, 1 bad row reported');
    console.log('\nALL ' + n + ' CHECKS PASSED');
  } catch (e) { console.error('\nFAILED:', e.message); console.error(e.stack.split('\n').slice(1, 4).join('\n')); process.exitCode = 1; }
  srv.close();
});
